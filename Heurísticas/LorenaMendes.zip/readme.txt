Nome: Lorena Mendes Peixoto
Matrícula: 2017015002
Heurística Construtiva: vizinho mais próximo

Descrição do programa:

O arquivo de entrada é lido e são coletadas as informações "dimensão" e "tipo", referentes aos vértices de entrada. Em seguida, são lidos os vértices e suas respectivas coordenadas em x e y.

Terminada a leitura, começa o algoritmo. Calcula-se a distância euclidiana do primeiro vértice aos demais e seleciona-se a aresta de menor custo. A partir da mesma, repete-se o procedimento sem visitar aqueles que já foram vistos. O algoritmo é repetido iniciando-se em cada vértice de forma a encontrar um caminho que tenha o menor custo.