VND: utiliza a implementação anterior (da heurística do vizinho mais próximo) e faz uma melhoria a partir da melhora da solução com 2-opt e 3-opt.
