/*
UNIVERSIDADE FEDERAL DE MINAS GERAIS
DEPARTAMENTO DE CIÊNCIA DA COMPUTAÇÃO
ALGORITMOS E ESTRUTURAS DE DADOS II
======================================
TP0: HIT DO VERÃO
ALUNA:			Lorena Mendes Peixoto
======================================

Módulo: ListaDeAdjacencia.c
*/

#include "ListaDeAdjacencia.h"
#include <stdio.h>
#include <stdlib.h>

int ProcuraLista(Relacao * lista, Pessoa pessoa){
	printf("Visitando a lista da pessoa %d\n",pessoa.id);
	//recebo a pessoa inicial
	if(pessoa.pesquisa == 1){
		//se eu já tiver pesquisado nessa pessoa, retorno 0
		printf("A pesquisa já foi feita aqui\n");
		return 0;
	}
	//essa pessoa passa ser uma já pesquisada
	pessoa.pesquisa = 1;

	//se a pessoa não tiver relações, retorno 0  
	if(lista[pessoa.id].tot_relacoes == 0){
		printf("A pessoa %d não tem relações\n", pessoa.id);
		return 0;
	}
	//se a pessoa tiver ao menos uma relação
	else{
		//crio uma variável contendo a célula da primeira pessoa que se relaciona com a pessoa inicial
		Relacao * tmp;
		tmp = lista[pessoa.id].prox;
		//enquanto ainda houver relação
		while(tmp != NULL){
			//pesquiso nas relações da pessoa apontada por tmp
			ProcuraLista(lista, tmp->fulano);// printf("a pesquisa de %d é %d\n", tmp->fulano.id, tmp->fulano.pesquisa);
			tmp = tmp->prox;
		}
	} 
	
	return 1;
}

void Imprimir_Lista(Relacao *lista, int num_pessoas){
	int i;
	Relacao *tmp;
	for(i=1; i<num_pessoas; i++){
		tmp = lista[i].prox;
		printf("Pessoa %d: (%d relações) ==> ", i, lista[i].tot_relacoes);
		while(tmp != NULL){
			printf(" %d (%d anos)", tmp->fulano.id, tmp->fulano.idade);
			tmp = tmp->prox;
		}
		printf("\n");
	}
}

void Inserir_Relacao(Relacao *lista, Pessoa a, Pessoa b){
	Relacao * ant;
	Relacao * seg;
	Relacao * nova;
	
	nova = (Relacao*) malloc((int)sizeof(Relacao));
	nova->prox = NULL;
	nova->fulano.id = b.id;
	nova->fulano.idade = b.idade;

	lista[a.id].tot_relacoes++;
	if(lista[a.id].prox == NULL){
		lista[a.id].prox = nova;
	} else {
		ant = lista[a.id].prox;
		seg = ant->prox;

		if(seg == NULL){
			if(ant->fulano.id < b.id){
				ant->prox = nova;
				return;
			} else {
				seg = ant;
				lista[a.id].prox = nova;
				nova->prox = seg;
				return;
			}
		}
		while(seg->prox != NULL && seg->prox->fulano.id < b.id){
			ant = ant->prox;
			seg = seg->prox;
		}
		ant = ant->prox;
		seg = seg->prox;
		ant->prox = nova;
		nova->prox = seg;
	}
}