#include "ListaDeAdjacencia.h"
#include <stdio.h>
#include <stdlib.h>

// 5
// 5
// 1 15
// 2 26
// 3 32
// 4 40
// 5 35
// 1 2
// 3 2
// 1 3
// 3 4
// 3 5
// 2


int main(){
	int num_pessoas, num_relacoes, i;
	scanf("%d %d", &num_pessoas, &num_relacoes);

	Relacao * nova;
	nova = (Relacao*) malloc(2 * num_relacoes * sizeof(Relacao));
	Pessoa * pessoa;
	pessoa = (Pessoa *) malloc(num_pessoas * sizeof(Pessoa));

	for(i=0; i<num_pessoas; i++){
		scanf("%d %d", &pessoa[i].id, &pessoa[i].idade);
		pessoa[i].pesquisa = 0;
		nova[i].tot_relacoes = 0;
		nova[i].prox = NULL;
	}
	printf("\n");

	int p1, p2;
	for(i=0; i<num_relacoes; i++){
		scanf("%d %d", &p1, &p2);
		Inserir_Relacao(nova, pessoa[p1-1], pessoa[p2-1]);
		Inserir_Relacao(nova, pessoa[p2-1], pessoa[p1-1]);
	}	

	Imprimir_Lista(nova, num_pessoas);

	Pessoa primeira;
	scanf(" %d", &primeira.id);

	// printf("Primeira pessoa a ouvir a música: %d\n", primeira.id);
	// printf("Id da pessoa: %d\nId da posição: %d\n", primeira.id, nova[primeira.id].prox->fulano.id+1);

	int lola = 0;
	lola = ProcuraLista(nova, num_pessoas, primeira);
	//isso tá errado, era pra imprimir quantas pessoas eu visitei
	printf("Lola: %d\n", lola);

	return 0;
}