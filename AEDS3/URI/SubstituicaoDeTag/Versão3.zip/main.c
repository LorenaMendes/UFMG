#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void print(char * string){
   printf("%s", string);
   printf("\n");
}

void shift(char * new_txt, int position, char * aux){
   int i;
   for(i=0; aux[i] != '\0'; i++){
      if(aux[i+1] == '\0') new_txt[position+i+1] = '\0';
      new_txt[position+i] = aux[i];
   }
   // print(new_txt);
   return;
}

char * substitution(char * new_txt, char * num, int position, int key_size, int txt_size){
   printf("Cheguei na função substitution\n");
   char aux[51];
   int i;
   int index = position + key_size;
   for(i=0; i<51; i++){
      if(new_txt[index+i] == '\0'){
         printf("tô no final\n");
         aux[i] = '\0';
         break;
      }
      aux[i] = new_txt[index+i];
      // printf("Cheguei aqui\n");
      // printf("%c\n", aux[i]);
   }
   print(aux);
   // //I've created a copy from the rest of the text after the key
   for(i=0; i<=strlen(num)-1; i++){
      if(i == strlen(num)-1){
         shift(new_txt, position+i, aux);
         break;;
      }
      new_txt[position+i] = num[i];
   }
   return new_txt;
}

int search(char * txt, char * key, int key_size, int position){
   printf("Cheguei na função search\n");
   int i;
   for(i=1; i < key_size; i++){
      if(key[i] != txt[position]) return 0;
      position ++;
   }
   return 1;
}

int main(){
   char key[11], buff[5], txt[51], new_txt[51];
   int i;
	while(fgets(key, 11, stdin)){
		int key_size = strlen(key) - 1;
      
      fgets(buff, 5, stdin);
      int num = atoi(buff);
      
      fgets(txt, 51, stdin);
      int txt_size = strlen(txt) - 1;
      
      strcpy(new_txt, txt);
      for(i=0; txt[i] != '\0'; i++){
         if(txt[i] == key[0]){
            //if a first match
            if(search(txt, key, key_size, i+1)){
               //if there is a full match
               strcpy(txt, substitution(txt, buff, i, key_size, txt_size));
            }
         }
      }
      // print(txt);
   }
}