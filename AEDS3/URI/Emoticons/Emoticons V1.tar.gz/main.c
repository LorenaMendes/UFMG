#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DEBUG 0

int search(char * txt, char * key, int key_size, int position){
   int i;
   for(i=1; i<key_size; i++){
      if(key[i] != txt[position]){
         return 0;
      }
      position ++;
   }
   return 1;
}

int main(){
   int i, j, k, counter = 0;
   int num_lines, num_emo;
   char * line = malloc(80 * sizeof(char));
   
   while(!feof(stdin)){
      scanf("%d %d\n", &num_emo, &num_lines);
      if(num_emo == 0 && num_lines == 0) break;
      if(DEBUG) printf("%d EMOTICONS e %d LINHAS\n", num_emo, num_lines);
      
      char ** emoticons = malloc(num_emo * sizeof(char *));
      for(i=0; i<num_emo; i++) emoticons[i] = malloc(sizeof(char));
      
      for(i=0; i<num_emo; i++){
         fgets(emoticons[i], 16, stdin);
         if(DEBUG) printf("EMOTICON %d: %s", i+1, emoticons[i]);
      }

      for(i=0; i<num_lines; i++){
         fgets(line, 80, stdin);
         printf("Linha %d de tamanho %ld: %s\n", i+1, strlen(line)-1, line);
         if(DEBUG) printf("LINHA %d: %s", i+1, line);
         for(j=0; j<num_emo; j++){
            for(k=0; k<(strlen(line)-1); k++){
               if(line[k] == emoticons[j][0]){
                  if(search(line, emoticons[j], strlen(emoticons[j])-1, i+1)){
                     counter ++;
                     //remove emoticon
                  }
               }
            }
         }
         printf("Number of emoticons found in line %d: %d\n", i+1, counter);
      }
      printf("Total number of emoticons found: %d\n", counter);
      if(DEBUG) printf("\n");
      counter = 0;
   }

	// while(fgets(key, 12, stdin)){
	// 	int key_size = strlen(key) - 1;
      
 //      fgets(buff, 6, stdin);
 //      int num = atoi(buff);
      
 //      fgets(txt, 52, stdin);
      
 //      strcpy(new_txt, txt);
 //      for(i=0; txt[i] != '\0'; i++){
 //         if(isEqual(txt[i], key[0])){
 //            //if a first match
 //            if(search(txt, key, key_size, i+1) && isTag(txt, i)){
 //               //if there is a full match
 //               strcpy(txt, substitution(txt, buff, i, key_size));
 //            }
 //         }
 //      }
 //      printf("%s", txt);
 //   }
}