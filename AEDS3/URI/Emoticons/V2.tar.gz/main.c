#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DEBUG 0

int search(char * txt, char * key, int key_size, int position){
   int i;
   for(i=1; i<key_size; i++){
      // printf("\nComparing %c with %c\n", key[i], txt[position]);
      if(key[i] != txt[position]){
         return 0;
      }
      position ++;
   }
   // printf("achei!\n");
   return 1;
}

char * substitution(char * new_txt, int position, int key_size){
   char aux[51];
   int i;
   int index = position + key_size;
   for(i=0; i<51; i++){
      if(new_txt[index+i] == '\0'){
         aux[i] = '\0';
         break;
      }
      aux[i] = new_txt[index+i];
   }
   // //I've created a copy from the rest of the text after the key
   for(i=0; i<=key_size; i++){
      // if(i == strlen(num)-1){
      //    shift(new_txt, position+i, aux);
      //    break;;
      // }
      //copying the number to the key's place in the text
      new_txt[position+i] = ' ';
   }
   return new_txt;
}

int main(){
   int i, j, k, counter = 0, bla = 0;
   int num_lines, num_emo;
   char * line = malloc(80 * sizeof(char));
   
   while(!feof(stdin)){
      scanf("%d %d\n", &num_emo, &num_lines);
      if(num_emo == 0 && num_lines == 0) break;
      if(DEBUG) printf("%d EMOTICONS e %d LINHAS\n", num_emo, num_lines);
      
      char ** emoticons = malloc(num_emo * sizeof(char *));
      for(i=0; i<num_emo; i++) emoticons[i] = malloc(sizeof(char));
      
      //allocates emoticons in a vector
      for(i=0; i<num_emo; i++){
         fgets(emoticons[i], 16, stdin);
         // /*if(DEBUG) */printf("EMOTICON %d: %s", i+1, emoticons[i]);
      }

      //reads a line and       
      for(i=0; i<num_lines; i++){
         fgets(line, 80, stdin);
         printf("Linha %d de tamanho %ld: %s\n", i+1, strlen(line)-1, line);
         if(DEBUG) printf("LINHA %d: %s", i+1, line);
         
         //for each emoticon, search the entire line
         for(j=0; j<num_emo; j++){
            for(k=0; k<(strlen(line)-1); k++){
               if(line[k] == emoticons[j][0]){
                  if(search(line, emoticons[j], strlen(emoticons[j])-1, k+1)){
                     counter ++;
                     printf("I found it: %s", emoticons[j]);
                     //remove emoticon
                     substitution(line, k+1, strlen(emoticons[j])-1);

                  }
               }
            }
         }
         printf("\nNumber of emoticons found in line %d: %d\n", i+1, counter);
         bla += counter;
         counter = 0;
      }
      printf("Total number of emoticons found: %d\n", bla);
      if(DEBUG) printf("\n");
      counter = 0;
   }

	// while(fgets(key, 12, stdin)){
	// 	int key_size = strlen(key) - 1;
      
 //      fgets(buff, 6, stdin);
 //      int num = atoi(buff);
      
 //      fgets(txt, 52, stdin);
      
 //      strcpy(new_txt, txt);
 //      for(i=0; txt[i] != '\0'; i++){
 //         if(isEqual(txt[i], key[0])){
 //            //if a first match
 //            if(search(txt, key, key_size, i+1) && isTag(txt, i)){
 //               //if there is a full match
 //               strcpy(txt, substitution(txt, buff, i, key_size));
 //            }
 //         }
 //      }
 //      printf("%s", txt);
 //   }
}