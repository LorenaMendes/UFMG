#include <stdio.h>
#include <stdlib.h>

int sortstring(const void * a, const void * b){
    int *A = (int *)a;
    int *B = (int *)b;
    return (A - B);
}

int ordena_vetor(int vet_alunos[], int tamanho){
	int aux, i, j, contador=0;
	int vet_aux[tamanho];
	for(i=0; i<tamanho; i++) vet_aux[i] = i;
	for(j=tamanho-1; j>=1; j--){
		for(i=0; i<j; i++){
			if(vet_alunos[i] > vet_alunos[i+1]){
				contador++;
				aux=vet_alunos[i];
                vet_alunos[i]=vet_alunos[i+1];
                vet_alunos[i+1]=aux;
                aux = vet_aux[i];
                vet_aux[i] = vet_aux[i+1];
                vet_aux[i+1] = aux;
            }
        }
    }
    return contador;
}

int main(){
	int i, tam;
	while(!feof(stdin)){
		scanf("%d", &tam);
		if(!tam) break;
		int * vetor;
		vetor = malloc(tam * sizeof(int));
		for(i=0; i<tam; i++){
			scanf(" %d", &vetor[i]);
		}
		if(ordena_vetor(vetor, tam)%2) printf("Marcelo\n");
		else printf("Carlos\n");
	}
	return 0;
}
