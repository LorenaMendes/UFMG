#include "Servers.h"
#include <stdio.h>
#include <stdlib.h>
#define DEBUG 0

int sortstring (const void * a, const void * b){
	Server *A = (Server *)a;
	Server *B = (Server *)b;
    printf("Comparando %d com %d\n", A->id, B->id);
	return ( B->id - A->id );
}

int main(){
	int num_servers, conections, i, colors = 0;
	scanf("%d\n", &num_servers);
	scanf("%d\n", &conections);

	Server ** vec_servers = (Server **) malloc(num_servers * sizeof(Server *));
	for(i=0; i<num_servers; i++) vec_servers[i] = NewServer(i+1);

	int s1, s2;
	for(i=0; i<conections; i++){
		scanf("%d %d", &s1, &s2);
		InsertConection(vec_servers, s1, s2);
		InsertConection(vec_servers, s2, s1);
	}

	Print(vec_servers, num_servers);
	printf("\nDegrees: ");
	for (i = 0; i < num_servers; i++){
		printf("%d ", vec_servers[i]->degree);
	} printf("\n\n");

	// qsort(vec_servers, num_servers, sizeof(Server), sortstring);

	// FindColor(vec_servers, num_servers);

	return 0;
}