#include "Servers.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

Server * NewServer(int id){
	Server * new = (Server *) malloc(sizeof(Server));
	new->id = id;
	new->updated = 0;
	new->color = 0;
	new->degree = 0;
	new->next = NULL;
	return new;
}

void InsertConection(Server ** vec_servers, int s1, int s2){
	printf("Connecting %d to %d... ", s1, s2);
	Server * aux;
	//cria uma pessoa com as características da que será inserida
	Server * new = NewServer(s1);
	vec_servers[s2-1]->degree ++;
	//se não tiver ninguém na lista, adiciona a nova ali
	if(vec_servers[s2-1]->next == NULL) vec_servers[s2-1]->next = new;
	else {
		aux = vec_servers[s2-1]->next;
		vec_servers[s2-1]->next = new;
		new->next = aux;
	}
	printf("Successfully connected!\n");
}

void Print(Server ** vec_servers, int num_servers){
	int i;
	Server * aux = NewServer(0);
	printf("\n");
	for(i=1; i<=num_servers; i++){
		aux = vec_servers[i-1]->next;
		printf("Server %d (%d): ==> ", i, vec_servers[i-1]->degree);
		while(aux != NULL){
			printf(" %d", aux->id);
			aux = aux->next;
		}
		printf("\n");
	}
}

// int FindColor(Server ** vec_servers, int num_servers){
// 	int i;
// 	for (i=0; i<num_servers; i++){
// 		if(!vec_servers[i]->updated)
// 	}
// }