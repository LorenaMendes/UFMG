#ifndef __SERVERS__
#define __SERVERS__

typedef struct Server{
	int id;
	int color;
	int updated;
	int degree;
	struct Server *next;
} Server;

// void LiberaEspaco(Pessoa *lista, int tam_lista);
// void ProcuraLista(Pessoa * lista, int tam_lista, int pessoa, int *cont);
int HasConnection(Server ** vec_servers, int s1, int s2);
void Print(Server ** vec_servers, int num_servers);
Server * NewServer(int id);
void InsertConection(Server ** vec_servers, int s1, int s2);


#endif