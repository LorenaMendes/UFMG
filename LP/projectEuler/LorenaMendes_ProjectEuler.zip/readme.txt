## Informações para execução dos programas

--> Python
	$ python lychrel.py 

--> SML
	$ sml lychrel.sml
	- result 10000;

--> Prolog
	$ prolog lychrel.pl
	-result(A).