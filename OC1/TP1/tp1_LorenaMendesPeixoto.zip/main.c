#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <endian.h>
#define DEBUG 0

typedef struct instruction{
	char type;
	int opcode;
	int destiny;
	int operator1;
	int operator2;
	int shift;
	int immediate;
	int funct;
	int address;
} Instruction;

int twoComplement(int number);
void executeInstructions(Instruction * memory, int * registers, int size);
void defineFirstHalf(Instruction * memory, int pos, int row);
void defineSecondHalf(Instruction * memory, int pos, int row);
void DtoB(int n);

int main(int argc, char const *argv[]){
	FILE *binary_file;
	binary_file = fopen(argv[1],"rb");
	if (!binary_file){
		printf("Unable to open file!");
		return 1;
	}
	int first_half, second_half;
	int pos = 0, i;
	Instruction * memory = malloc(0x1000 * sizeof(Instruction));
	int * registers = malloc(0x1000 * sizeof(int));
	while(!feof(binary_file)){
		fread(&first_half, 2, 1, binary_file);
		defineFirstHalf(memory, pos, htobe32(first_half));
		fread(&second_half, 2, 1, binary_file);
		defineSecondHalf(memory, pos, htobe32(second_half));
		pos ++;
	}
	if(DEBUG){
		for (i = 0; i < pos-1; i++){
			printf("Opcode da instrução %d: %d\n", i+1, memory[i].opcode);
		}
	}
	executeInstructions(memory, registers, pos-1);
	return 0;
}

void defineFirstHalf(Instruction * memory, int pos, int row){
	int opcode = row >> 26;
	opcode = opcode & 63;
	memory[pos].opcode = opcode;
	
	switch(opcode){
		case 0:
			if(DEBUG) printf("\nÉ DO TIPO R\n");
			//define type
			memory[pos].type = 'r';
			//define operator1
			int operator1 = row >> 21;
			operator1 = operator1 & 31;
			memory[pos].operator1 = operator1;
			if(DEBUG) printf("     operator1 vale %d: ", operator1);
			if(DEBUG) DtoB(operator1);
			//define operator2
			int operator2 = row >> 16;
			operator2 = operator2 & 31;
			memory[pos].operator2 = operator2;
			if(DEBUG) printf("     operator2 vale %d: ", operator2);
			if(DEBUG) DtoB(operator2);
			break;
		case 2:
		case 3:
		case 63:
			// define type
			memory[pos].type = 'j';
			//define address
			int address = row >> 0;
			address = address & 67043328;
			memory[pos].address = address;
			if(DEBUG) DtoB(address);
			break;
		default:
			if(DEBUG) printf("\nÉ DO TIPO I\n");
			//define type
			memory[pos].type = 'i';
			//define operator1
			operator1 = row >> 21;
			operator1 = operator1 & 31;
			memory[pos].operator1 = operator1;
			if(DEBUG) printf("     operator1 vale %d: ", operator1);
			if(DEBUG) DtoB(operator1);
			//define destiny
			int destiny = row >> 16;
			destiny = destiny & 31;
			memory[pos].destiny = destiny;
			if(DEBUG) printf("     destiny vale %d: ", destiny);
			if(DEBUG) DtoB(destiny);
			break;
	}
}

void defineSecondHalf(Instruction * memory, int pos, int row){
	switch(memory[pos].type){
		int destiny;
		int immediate;
		int address;
		case 'r':
			//define destiny
			destiny = row >> 27;
			destiny = destiny & 31;
			memory[pos].destiny = destiny;
			if(DEBUG) printf("     destiny vale %d: ", destiny);
			if(DEBUG) DtoB(destiny);
			//define shift
			int shift = row >> 22;
			shift = shift & 31;
			memory[pos].shift = shift;
			if(DEBUG) printf("     shift vale %d: ", shift);
			if(DEBUG) DtoB(shift);
			//define funct
			int funct = row >> 16;
			funct = funct & 63;
			memory[pos].funct = funct;
			if(DEBUG) printf("     funct vale %d: ", funct);
			if(DEBUG) DtoB(funct);
			break;
		case 'i':
			//define immediate
			immediate = row >> 16;
			immediate = immediate & 65535;
			memory[pos].immediate = immediate;
			if(DEBUG) printf("     immediate vale %d: ", immediate);
			if(DEBUG) DtoB(immediate);
			break;
		case 'j':
			address = row >> 16;
			address = address & 1023;
			memory[pos].address += address;
			if(DEBUG) printf("     address vale %d: ", address);
			if(DEBUG) DtoB(address);
			break;
	}
}

void executeInstructions(Instruction * memory, int * registers, int size){
	int PC = 0, i, input;
	for (i = 0; i < size; i++){
		if(memory[i].type == 'i'){
			switch(memory[i].opcode){
				case 62:
					if(DEBUG) printf("É um IN\n");
					scanf("%d", &input);
					registers[memory[i].operator1] = input;
					break;
				case 61:
					if(DEBUG) printf("É um OUT\n");
					printf("%d\n", registers[memory[i].operator1]);
					break;
				case 8:
					if(DEBUG) printf("É um ADDI\n");
					if(memory[i].immediate >= 32768){
						memory[i].immediate = memory[i].immediate ^ 65535;
						memory[i].immediate = memory[i].immediate + 1;
						registers[memory[i].destiny] = registers[memory[i].operator1] - memory[i].immediate;
					} else {
						registers[memory[i].destiny] = registers[memory[i].operator1] + memory[i].immediate;
					}
					break;
				case 12:
					if(DEBUG) printf("É um ANDI\n");
					registers[memory[i].destiny] = registers[memory[i].operator1] & memory[i].immediate;
					break;
				case 35:
					if(DEBUG) printf("É um LW\n");
					registers[memory[i].destiny] = registers[registers[memory[i].operator1] + memory[i].immediate];
					break;
				case 13:
					if(DEBUG) printf("É um ORI\n");
					registers[memory[i].destiny] = registers[memory[i].operator1] | memory[i].immediate;
					break;
				case 43:
					if(DEBUG) printf("É um SW\n");
					registers[registers[memory[i].operator1] + memory[i].immediate] = registers[memory[i].destiny];
					break;
				case 4:
					if(DEBUG) printf("É um BEQ\n");
					if(registers[memory[i].operator1] == registers[memory[i].destiny]){
						PC = memory[i].immediate;
						i = PC-1;
						break;
					} else break;
				case 7:
					if(DEBUG) printf("É um BGTZ\n");
					if(registers[memory[i].operator1] > 0) PC = memory[i].immediate;
					i = PC-1;
					break;
				case 1:
					if(DEBUG) printf("É um BLTZ\n");
					if(registers[memory[i].operator1] < 0) PC = memory[i].immediate;
					i = PC-1;
					break;
				case 5:
					if(DEBUG) printf("É um BNE\n");
					if(registers[memory[i].operator1] != registers[memory[i].destiny]) PC = memory[i].immediate;
					i = PC-1;
					break;
			}
		} else if(memory[i].type == 'r'){
			switch(memory[i].funct){
				case 32:
					if(DEBUG) printf("É um ADD\n");
					//both negative
					if(registers[memory[i].operator1] >= 32768 && registers[memory[i].operator2] >= 32768){
						registers[memory[i].operator1] = twoComplement(registers[memory[i].operator1]);
						registers[memory[i].operator2] = twoComplement(registers[memory[i].operator2]);
						registers[memory[i].destiny] = registers[memory[i].operator1] + memory[i].immediate;
						registers[memory[i].destiny] = twoComplement(registers[memory[i].destiny]);					}
					//op1 negative only
					else if(registers[memory[i].operator1] >= 32768 && registers[memory[i].operator2] < 32768){
						registers[memory[i].operator1] = twoComplement(registers[memory[i].operator1]);
						registers[memory[i].destiny] = registers[memory[i].operator2] - registers[memory[i].operator1];
					}
					//op2 negative only
					else if(registers[memory[i].operator2] >= 32768 && registers[memory[i].operator1] < 32768){
						registers[memory[i].operator2] = twoComplement(registers[memory[i].operator2]);
						registers[memory[i].destiny] = registers[memory[i].operator1] - registers[memory[i].operator2];
					}
					//both positive
					else if(registers[memory[i].operator2] < 32768 && registers[memory[i].operator1] < 32768)
						registers[memory[i].destiny] = registers[memory[i].operator1] + registers[memory[i].operator2];
					break;
				case 36:
					if(DEBUG) printf("É um AND\n");
					registers[memory[i].destiny] = registers[memory[i].operator1] & registers[memory[i].operator2];
					break;
				case 42:
					if(DEBUG) printf("É um DIV\n");
					registers[memory[i].destiny] = registers[memory[i].operator1] / registers[memory[i].operator2];
					break;
				case 24:
					if(DEBUG) printf("É um MULT\n");
					registers[memory[i].destiny] = registers[memory[i].operator1] * registers[memory[i].operator2];
					break;
				case 37:
					if(DEBUG) printf("É um OR\n");
					registers[memory[i].destiny] = registers[memory[i].operator1] | registers[memory[i].operator2];
					break;
				case 38:
					if(DEBUG) printf("É um XOR\n");
					registers[memory[i].destiny] = registers[memory[i].operator1] ^ registers[memory[i].operator2];
					break;
				case 34:
					if(DEBUG) printf("É um SUB\n");
					registers[memory[i].destiny] = registers[memory[i].operator1] - registers[memory[i].operator2];
					break;
				case 0:
					if(DEBUG) printf("É um SLL\n");
					registers[memory[i].destiny] = registers[memory[i].operator2] << memory[i].shift;
					break;
				case 2:
					if(DEBUG) printf("É um SRL\n");
					registers[memory[i].destiny] = registers[memory[i].operator2] >> memory[i].shift;
					break;
				case 8:
					if(DEBUG) printf("É um JR\n");
					PC = registers[memory[i].operator1];
					i = PC-1;
					break;

			}
		} else if(memory[i].type == 'j'){
			switch(memory[i].opcode){
				case 2:
					if(DEBUG) printf("É um J\n");
					PC = memory[i].address;
					i = PC-1;
					break;
				case 63:
					return;
				case 0:
					PC = registers[memory[i].operator1];
					i = PC-1;
					break;
				case 3:
					registers[31] = PC+1;
					PC = memory[i].address;
					i = PC-1;
					break;
			}	
		}
		PC++;
	}
}

int twoComplement(int number){
	number = number ^ 65535;
	number = number + 1;
	return number;
}

void DtoB(int decimal){
	int binary, i;
	for(i = 31; i >= 0; i--) {
		binary = decimal >> i;
		if(binary & 1) printf("1");
		else printf("0");
	}
	printf("\n");
}