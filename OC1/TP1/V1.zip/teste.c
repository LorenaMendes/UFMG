#include <stdio.h>
#include <string.h>
#include <stdlib.h>


void getOpcode(int * vector){
	int i, opcode[6];
	char ch_opcode[6];
	for(i=31; i>=26; i--){
		printf("%d: %d\n", i+1, vector[i]);
		opcode[i] = vector[i];
	}
	for(i=0; i<6; i++){
		printf("%d", vector[i]);
		ch_opcode[i] = (char)vector[i];
		printf("%c", ch_opcode[i]);
	}
	// printf("opcode: %s\n", ch_opcode);
}

void getBinary(unsigned int decimal){
	unsigned int num = decimal;
	unsigned int vet_bin[32];
	int j, i = 0;
	while(decimal > 0){
		vet_bin[i] = decimal % 2;
		i++;
		decimal = decimal / 2;
	}
	for(i; i<32; i++) vet_bin[i] = 0;
	printf("%u em binario: ", num);
	for(j = i - 1; j >= 0; j--) printf("%d", vet_bin[j]);
	printf("\n");
	getOpcode(vet_bin);
}

int main(){
	// FILE *ptr_myfile;
	// int my_record;

	// ptr_myfile = fopen("calculadora","rb");
	// if (!ptr_myfile){
	// 	printf("Unable to open file!");
	// 	return 1;
	// }
	// fread(&my_record, 4, 1, ptr_myfile);
	// my_record = (int)my_record;
	getBinary(1888800006);
	printf("\n");
	return 0;
}