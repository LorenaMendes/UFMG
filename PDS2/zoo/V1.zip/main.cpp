#include <iostream>
#include "Animal.hpp"
#include <map>
#include <vector>

using namespace std;

int calculaPorcentagem(int, int);

int main() {

	char comando;
	int semana_atual, peso_bicho;
	string nome_bicho;

	map<string, Animal*> zoo;
	map<string, Animal*>::iterator it;
	map<string, int> mapa;
	map<string, int>::iterator mit;

	while (cin >> comando) {
	
		if (comando == 'S'){
			cin >> semana_atual;
			
			for (it = zoo.begin(); it != zoo.end(); it++){
				if(it->second->getTempoPesagem(semana_atual) >= 2){
					if(mapa[it->second->getNome()]) mapa[it->second->getNome()]++;
					else mapa[it->second->getNome()] = it->second->getTempoPesagem(semana_atual);
				}
			}
		}
		else {
			cin >> nome_bicho >> peso_bicho;
			
			if (!zoo[nome_bicho]) {
				Animal * animal = new Animal();
				animal->setNome(nome_bicho);
				zoo[nome_bicho] = animal;
			}
		
			if(calculaPorcentagem(peso_bicho, zoo[nome_bicho]->getPeso())){
				cout << "Semana " << semana_atual << ": Aviso! Animal ";
				cout << zoo[nome_bicho]->getNome() << " perdeu 10% ou mais de seu peso." << endl;
			}
			
			// if(mapa.begin()->first == nome_bicho){

			// }

			for (mit = mapa.begin(); mit != mapa.end(); mit++){
				if(nome_bicho == mit->first){
					mapa.erase(mit);
					break;
				}
				cout << mit->first << ": ";
				cout << mit->second << endl;
			}

			zoo[nome_bicho]->setPeso(peso_bicho, semana_atual);
		}
	}

	for (it = zoo.begin(); it != zoo.end(); it++){
		delete((it->second));
	}

	return 0;
}

int calculaPorcentagem(int novoPeso, int peso){
	if(novoPeso >= peso) return 0;
	int porcentagem = peso * 0.1;
	if(peso - novoPeso >= porcentagem) return 1;
	else return 0;
}

/*
cout << "Semana " << semana_atual << ": Aviso! Animal ";
cout << vit->getNome() << " nao foi pesado por ";
cout << diff << " semanas." << endl;
*/