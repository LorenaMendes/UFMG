#include <string>
#include <iostream>
#include "Empregado.hpp"
using namespace std;

class Vendedor : public Empregado {

public:
	double quota_mensal_vendas;

	Vendedor(string, double, double);
	double calcula_quota_total_anual();

	double get_quota_mensal_vendas();
	void set_quota_mensal_vendas(double);

	void imprime_info();
};

