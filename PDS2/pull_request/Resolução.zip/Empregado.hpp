#ifndef EMPREGADO_H
#define EMPREGADO_H

#include <iostream>
#include <string>
using namespace std;

class Empregado {

public:
    string nome;
    double salario_hora;
    double salario_mes;

    Empregado(string, double);

    string get_nome();
    void set_nome(string);

    double get_salario_hora();
    void set_salario_hora(double);

    double get_salario_mes();
    void set_salario_mes(double);

    double calcula_salario_do_mes(double);

    virtual void imprime_info() {};
};

#endif