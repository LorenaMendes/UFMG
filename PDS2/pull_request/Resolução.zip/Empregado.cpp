#include <string>
#include <iostream>
#include "Empregado.hpp"
using namespace std;

int horaPadrao = 8;

Empregado::Empregado(string nome, double salario_hora) {
	set_nome(nome);
	set_salario_hora(salario_hora);
}

string Empregado::get_nome() {return this->nome;}

void Empregado::set_nome(string nome) {this->nome = nome;}

double Empregado::get_salario_hora() {return this->salario_hora;}
void Empregado::set_salario_hora(double salario_hora) {this->salario_hora = salario_hora;}

double Empregado::get_salario_mes() {return this->salario_mes;}
void Empregado::set_salario_mes(double salario_mes) {this->salario_mes = salario_mes;}

double Empregado::calcula_salario_do_mes(double horasTrabalhadas) {
	double horasContabilizadas = horasTrabalhadas;

	//Cálculo de hora extra (+50% se horasTrabalhadas > 8)
	if (horasTrabalhadas > horaPadrao) {
		double horasExtras = horasTrabalhadas - horaPadrao;
		horasContabilizadas += horasExtras / 2;
	}
	return horasContabilizadas * salario_hora;
}