#include <string>
#include <iostream>
#include "Empregado.hpp"
using namespace std;

class Engenheiro : public Empregado {

public:
	int projetos;

	Engenheiro(string, double, int);

	int get_projetos();
	void set_projetos(int);
	void imprime_info();
};