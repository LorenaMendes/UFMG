# Exercício Pull Request

O objetivo desse problema é praticar a parte de revisão e refatoração.

Você deve clonar esse repositório, fazer as alterações que julgar necessárias e então realizar um Pull Request. Você é livre para criar outros arquivos, classes, métodos, etc., desde que o main continue produzindo a mesma saída. Lembre-se que essa etapa não altera o comportamento funcional. No seu pull request faça uma breve lista/descrição das possíveis soluções que você utilizou.

Dica: Verifique o catálogo com sugestões de refatoração (https://refactoring.com/catalog/).

Criação de Empregado.cpp
Mudança nos nomes das variáveis para ficar mais natural
Passei nome para a classe pai
correção da identação para Tab 4
criei Engenheiro.hpp e passei o header para lá
criei construtores
criei variáveis globais