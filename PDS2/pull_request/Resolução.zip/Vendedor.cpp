#include <string>
#include <iostream>
#include "Vendedor.hpp"
using namespace std;

int anos = 12;

Vendedor::Vendedor(string nome, double salario_hora, double quota_mensal_vendas) : Empregado(nome, salario_hora) {
	set_nome(nome);
	set_salario_hora(salario_hora);
	set_quota_mensal_vendas(quota_mensal_vendas);
}

double Vendedor::calcula_quota_total_anual() {return this->quota_mensal_vendas * anos;}

double Vendedor::get_quota_mensal_vendas() {return this->quota_mensal_vendas;}

void Vendedor::set_quota_mensal_vendas(double quota_mensal_vendas) {this->quota_mensal_vendas = quota_mensal_vendas;}

void Vendedor::imprime_info() {
	cout << "Nome: " << this->get_nome() << endl;
	cout << "Salario Mes: " << this->get_salario_mes() << endl;
	cout << "Quota vendas: " << this->calcula_quota_total_anual() << endl;
	cout << endl;
}