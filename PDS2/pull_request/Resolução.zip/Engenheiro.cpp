#include <string>
#include <iostream>
#include "Engenheiro.hpp"
using namespace std;

Engenheiro::Engenheiro(string nome, double salario_hora, int projetos) : Empregado(nome, salario_hora){
	this->set_nome(nome);
	this->set_salario_hora(salario_hora);
	this->set_projetos(projetos);	
}

int Engenheiro::get_projetos(){return this->projetos;}

void Engenheiro::set_projetos(int projetos){this->projetos = projetos;}

void Engenheiro::imprime_info(){
	cout << "Nome: " << this->get_nome() << endl;
	cout << "Salario Mes: " << this->get_salario_mes() << endl;
	cout << "Projetos: " << this->get_projetos() << endl;
	cout << endl;
}