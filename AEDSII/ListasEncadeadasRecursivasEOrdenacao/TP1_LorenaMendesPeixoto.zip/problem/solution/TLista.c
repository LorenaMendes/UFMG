#include <stdlib.h>
#include <stdio.h>

#include "TLista.h"

#define DEBUG 0

//Função para preparar o vetor com os comentários para ser ordenado e impresso
TVetor * ImprimeLista(TLista * lista, TVetor * vetor) {
	TCelula * temp;
	temp = malloc(sizeof(TCelula));
	int posicao = 0;
	if (lista != NULL) temp = lista->primeira;
	else {
		return NULL;
	}
	do {
		if (temp->id != 0) {
			// if (temp->id == 0) printf(" ");
			// else printf("%d ", temp->id);
			vetor->array[vetor->tamanho] = temp->id;	//preenche o vetor com os comentários
			posicao ++;
			vetor->tamanho ++;
		}
		if (temp->respostas != NULL) {
			// printf("{");
			ImprimeLista(temp->respostas, vetor);	//chama recursivamente a função
			// printf("}");
		}
		temp = temp->proxima;
	} while (temp != NULL);
	return vetor;
}

//Cria e adiciona um comentário ao final de uma lista e retorna o comentário criado
TCelula * Adiciona(TLista * lista, int id) {
	TCelula * novo;
	novo = malloc(sizeof(TCelula));
	novo->id = id;
	novo->proxima = NULL;
	novo->anterior = NULL;
	novo->respostas = NULL;
	novo->atual = lista;

	TCelula * temp = lista->primeira;
	if (temp == NULL) lista->primeira = novo;
	else {
		while (temp->proxima != NULL) temp = temp->proxima;	//percorre a lista até chegar no último
		temp->proxima = novo;	//adiciona o novo comentário
		novo->anterior = temp;
	}
	return novo;	//retorna o comentário criado
}

TCelula * Responde(TLista * lista, int idExistente, int idNovo) {
	TCelula * existente = EncontraComentario(lista, idExistente);
	if (existente == NULL) return NULL;
	if (existente->respostas == NULL) {	//se encontrar o comentário a se responder,
		TLista * resps;
		resps = malloc(sizeof(TLista));
		resps->primeira = NULL;
		resps->ultima = NULL;
		existente->respostas = resps;
	}
	return Adiciona(existente->respostas, idNovo);	//adiciona um novo nas respostas dele
}

//retorna a célula de um comentário a partir de um id em uma lista
TCelula * EncontraComentario(TLista * lista, int id) {
	TCelula * temp;
	temp = malloc(sizeof(TCelula));
	if (lista != NULL) temp = lista->primeira;
	else {
		return NULL;	//caso de lista nula
	}
	if (lista->primeira == NULL) return NULL;
	else {
		do {
			if (temp->id == id)	return temp;	//percorre toda a lista à procura do id passado por parâmetro
			if (temp->respostas != NULL) {
				TCelula * temporaria = EncontraComentario(temp->respostas, id);	//chama recursivamente a função
				if (temporaria != NULL) {
					return temporaria;
				}
			}
			temp = temp->proxima;
		} while (temp != NULL);
	}
	return NULL;
}

void Remove(TCelula * existente) {
	//se a função EncontraComentario() retornar NULL, a célula não existe e a função não é executada
	if (existente == NULL) {
		return;
	}

	//verifica o caso de a célula ser a primeira da lista e manipula os apontadores
	if (existente->anterior == NULL && existente->proxima != NULL) {
		existente->proxima->anterior = NULL;
		existente->id = 0;
	}

	//verifica o caso de a célula ser a única da lista e manipula os apontadores
	else if (existente->anterior == NULL && existente->proxima == NULL) {
		existente->id = 0;
	}

	//verifica o caso de a célula ser a última da lista e manipula os apontadores
	else if (existente->anterior != NULL && existente->proxima == NULL) {
		existente->anterior->proxima = NULL;
		existente->id = 0;
	}

	//verifica o caso de a célula não ser primeira nem última da lista e manipula os apontadores
	else if (existente->anterior != NULL && existente->proxima != NULL) {
		existente->anterior->proxima = existente->proxima;
		existente->proxima->anterior = existente->anterior;
		existente->id = 0;
	}

	//se a célula não tiver filhas, termina o processo
	if (existente->respostas == NULL) {
		return;
	}

	//Altera os apontadores
	if (existente == existente->atual->primeira) existente->atual->primeira = existente->proxima;
	else {
		existente->anterior->proxima = existente->proxima;
		existente->proxima->anterior = existente->anterior;
	}
}
