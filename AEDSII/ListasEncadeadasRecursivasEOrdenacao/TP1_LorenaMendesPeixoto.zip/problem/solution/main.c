#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "TLista.h"

#define DEBUG 0

//ordena o vetor de comentários e o imprime no arquivo
void Ordena(FILE * output, TVetor * vetor) {
	if (vetor->tamanho == 0) {
		printf("-\n");
		fprintf(output, "-\n");
		return;
	}
	int i, j, tmp;
	for (i = 0; i < vetor->tamanho; i++) {
		printf("%d ", vetor->array[i]);
		fprintf(output, "%d ", vetor->array[i]);
	}
	printf("- ");
	fprintf(output, "- ");
	for (i = 1; i < vetor->tamanho; i++)
	{
		tmp = vetor->array[i];
		for (j = i - 1; j >= 0 && tmp < vetor->array[j]; j--)
			vetor->array[j + 1] = vetor->array[j];
		vetor->array[j + 1] = tmp;
	}
	for (i = 0; i < vetor->tamanho; i++) {
		printf("%d ", vetor->array[i]);
		fprintf(output, "%d ", vetor->array[i]);
	}
	printf("\n");
	fprintf(output, "\n");
}

// Função para traduzir o arquivo em comandos e parâmetros
void processaComando(FILE * file, FILE * output) {

	FILE *temp;
	// Variaveis auxiliares para conversao de String para Inteiro (funcao atoi) durante o processamento do arquivo de entrada.
	char idNovoAdd[100], idNovoRes[100], idExistente[100], c;
	int id_int_Novo, id_int_Existente, posicao = 0, i;

	//crio uma lista
	TLista * post;
	post = malloc(sizeof(TLista));
	post->primeira = NULL;
	post->ultima = NULL;

	while (c != EOF)	//enquando o arquivo não termina,
	{
		c = getc(file);	//pega um caractere do arquivo
		switch (c) {	//analisa a qual função ele se refere

		case 'A':
			temp = file;
			c = getc(temp); //cria uma variável temporária para não deslocar no arquivo original
			do {
				idNovoAdd[posicao] = c;
				posicao++;
				c = getc(temp);
				if (DEBUG == 2) printf("IdNovo: %s\n", idNovoAdd);
			} while (c >= 48 && c <= 57); 	//percorre, pegando o valor do parâmetro, até achar um novo comando
			idNovoAdd[posicao] = '\0';
			if (DEBUG == 2) printf("IdNovoAdd final: %s\n", idNovoAdd);
			posicao = 0;
			id_int_Novo = atoi(idNovoAdd);
			fseek(file, -1, SEEK_CUR);		//volta uma posição (pois, nesse momento, ele para no novo comando). Da próxima vez que usar o getc, ele pega o elemento seguinte, então o comando é "pulado"
			if (DEBUG) printf("[DEBUG] Adiciona, %d\n", id_int_Novo);
			Adiciona(post, id_int_Novo);
			for (i = 0; idNovoAdd[i] != '\0'; i++) idNovoAdd[i] = '\0';
			break;

		case 'R':
			temp = file;
			c = getc(temp);
			do {
				idExistente[posicao] = c;
				posicao++;
				c = getc(temp);
				if (DEBUG == 2) printf("IdExistente: %s\n", idExistente);
			} while (c >= 48 && c <= 57);
			idExistente[posicao] = '\0';
			posicao = 0;
			if (c == 44) {	//vê se o caractere é uma vírgula
				c = getc(temp);
				do {	//faz o mesmo processo, agora buscando o segundo parâmetro da função Responde()
					idNovoRes[posicao] = c;
					posicao++;
					c = getc(temp);
					if (DEBUG == 2) printf("IdNovoRes: %s\n", idExistente);
				} while (c >= 48 && c <= 57);
				id_int_Novo = atoi(idNovoRes);
				idNovoRes[posicao] = '\0';
				posicao = 0;
			}
			id_int_Existente = atoi(idExistente);
			fseek(file, -1, SEEK_CUR);
			if (DEBUG) printf("[DEBUG] Responde %d em %d\n", id_int_Novo, id_int_Existente);
			Responde(post, id_int_Existente, id_int_Novo);
			//for (i = 0; idExistente[i] != '\0'; i++) idExistente[i] = '\0';
			for (i = 0; idNovoRes[i] != '\0'; i++) idNovoRes[i] = '\0';
			break;

		case 'D':
			temp = file;
			c = getc(temp);
			do {
				idNovoAdd[posicao] = c;
				posicao++;
				c = getc(temp);
				if (DEBUG == 2) printf("IdNovo: %s\n", idNovoAdd);
			} while (c >= 48 && c <= 57);
			idNovoAdd[posicao] = '\0';
			if (DEBUG == 2) printf("IdNovoAdd final: %s\n", idNovoAdd);
			posicao = 0;
			id_int_Novo = atoi(idNovoAdd);
			fseek(file, -1, SEEK_CUR);
			if (DEBUG) printf("[DEBUG] Remove, %d\n", id_int_Novo);
			Remove(EncontraComentario(post, id_int_Novo));	//chama a função de remover
			for (i = 0; idNovoAdd[i] != '\0'; i++) idNovoAdd[i] = '\0';
			break;
		case '\n':
			if (DEBUG) printf("[DEBUG] LINEBREAK.\n");
			TLista * temp = post;
			TVetor * vetor;
			vetor = malloc(sizeof(vetor));
			vetor->tamanho = 0;
			Ordena(output, ImprimeLista(temp, vetor));	//quando chegar no fim de uma linha, imprime o resultado dos comandos
			printf("\n");
			post->primeira = NULL;
			post->ultima = NULL;
			break;
		case EOF:
			break;	//arquivo acabou
		default:
			if (DEBUG) printf("[DEBUG] Caractere invalido: %c\n", c);
			break;
		}
	}
	printf("Gerei o arquivo output.txt\n");
	fclose(output);
	return;
}

int main(int argc, char *argv[]) {
	printf("Argumentos: %d.\n------------------\n", argc);
	for (int i = 0; i < argc; i++) printf("Argumento %d: %s\n", i, argv[i]);	//mostra o número de argumentos informados.
	printf("\n");
	if (argc != 3) {	//se forem informados mais ou menos que 2 argumentos, dá uma mensagem de erro.
		printf("ERRO DE INPUT!\nDigite o nome do arquivo de entrada e o nome do arquivo de saída!\n");
		return 0;
	}


	if (DEBUG) printf("[DEBUG] Comecei.\n");
	FILE *file;
	file = fopen(argv[1], "r");	//abre o arquivo para leitura
	if (file == NULL) {
		printf("Erro ao abrir o arquivo de entrada.\n");
		return 0;
	}

	FILE *output;
	output = fopen(argv[2], "w");	//abre o arquivo para escrita
	if (output == NULL) {
		printf("Erro ao abrir o arquivo de saida.\n");
		return 0;
	}

	if (DEBUG) printf("[DEBUG] Abri o arquivo\n");
	if (file) {
		if (DEBUG) printf("[DEBUG] Processando arquivo...\n");
		processaComando(file, output);	//começa a ler o arquivo e chama a função para interpretar os comandos
		if (DEBUG) printf("[DEBUG] Processei.\n");
		fclose(file);
	}

	return 0;
}
