#include<stdio.h>
#include "TipoString.h"

int main() {
	
		printf("****Crio uma string inválida e tento imprimi-la na tela****");
		printf("\n");
		TipoString a = CriaString("minu5cu14");
		ImprimeString(a);
		printf("\n");
				
		printf("****Crio uma string com mais de 50 caracteres e tento imprimi-la na tela****");
		printf("\n");
		TipoString b = CriaString("TESTETESTETESTETESTETESTETESTETESTETESTETESTETESTEMAIS");
		ImprimeString(b);
		printf("\n");
		
		printf("****Crio uma string válida e a imprimo na tela****");
		printf("\n");
		TipoString c = CriaString("TESTANDO");
		ImprimeString(c);
		
		printf("\n****Crio uma string vazia****");
		printf("\n");
		TipoString x = CriaStringVazia();
		ImprimeString(x);
		
		printf("\n****Testando a função GetChar() com a string válida criada****");
		printf("\n");
		GetChar(c,15);
		GetChar(c,-3);
		GetChar(c,0);
		GetChar(c,5);
		
		printf("\n***Testando a função SetChar() com a string válida criada****");
		printf("\n");
		ImprimeString(c);
		SetChar(&c,0,'p');
		SetChar(&c,0,'8');
		SetChar(&c,0,'P');
		SetChar(&c,3,'C');
		ImprimeString(c);
		
		printf("\n****Testando a função InsereChar() com a string válida criada e modificada****");
		printf("\n");
		InsereChar(&c,'u');
		InsereChar(&c,'P');
		InsereChar(&c,'E');
		InsereChar(&c,'I');
		InsereChar(&c,'X');
		InsereChar(&c,'E');
		InsereChar(&c,'S');
		printf("String atual: ");
		ImprimeString(c);
		
		printf("\n****Testando a função GetTamanho() com a a string válida criada e modificada****");
		printf("\n");
		printf("Tamanho da string atual: %d",GetTamanho(c));
		printf("\n");
		
}
