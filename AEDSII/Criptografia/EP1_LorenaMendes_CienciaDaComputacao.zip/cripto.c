#include <stdio.h>
#include <stdlib.h>
#include "TipoString.h"

int main(int argc, char *argv[]) {
	printf("Argumentos: %d.\n------------------\n",argc);
	for(int i=0;i<argc;i++) printf("Argumento %d: %s\n",i,argv[i]);	//mostra o número de argumentos informados
	printf("\n");
	if(argc != 3) {	//se forem informados mais ou menos que 3 argumentos, dá uma mensagem de erro
		printf("ERRO DE INPUT!\nDigite o nome do programa, a mensagem e a chave!\n");
		return 0;
	}
	int msgSize, keySize;		//cria variáveis para o tamanho dos objetos
	int i;
	
	printf("Criando mensagem... ");
	TipoString msg = CriaString(argv[1]);	//cria um objeto que representa a mensagem a ser criptografada
	msgSize = GetTamanho(msg);	//atribui à variável o tamanho do objeto que representa a mensagem a ser criptografada
	if(!strcmp(msg.string,"a")) return 0;
	
	printf("Criando chave...... ");
	TipoString key = CriaString(argv[2]);	//cria um objeto que representa a chave da criptografia
	keySize = GetTamanho(key);	//atribui à variável o tamanho do objeto que representa a chave da criptografia
	if(!strcmp(key.string,"a")) return 0;
	
	TipoString crpt = CriaStringVazia();	//cria um objeto vazio para alocar a mensagem criptografada
	printf("\n");
		
	for(i=0;i<msgSize;i++){
		if((msg.string[i] + key.string[i%keySize] - 64) > 90){	//caso o caractere correspondente à soma ultrapasse Z,
			crpt.string[i] = msg.string[i] + key.string[i%keySize] - 90;	//atribui a cada posição da mensagem criptografada o caractere da mensagem + o caractere correspondente da chave de criptografia voltando à letra A após o Z
		} else	{
			crpt.string[i] = msg.string[i] + key.string[i%keySize] - 64;	//atribui a cada posição da mensagem criptografada o caractere da mensagem somado ao caractere correspondente da chave de criptografia
		}
	}
	crpt.string[msgSize] = '\0';	//insere um terminador de string ao final da mensagem válida, a fim de evitar interferência de lixo de memória
	printf("Criptografando sua mensagem...\n");
	
	printf("\n");
	printf("     Chave de criptografia: ");
	ImprimeString(key); //imprime a chave de criptografia
	printf("              Sua mensagem: ");
	ImprimeString(msg);	//imprime a mensagem a ser criptografada
	printf("Sua mensagem criptografada: ");	
	ImprimeString(crpt); //imprime a mensagem criptografada
	printf("\n");
	
	return 0;

}
