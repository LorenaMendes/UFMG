#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct TipoString{ //Cria tipo de dados TipoString
	char string[50];
} TipoString;

TipoString CriaString(char *str){ //Cria um objeto do tipo TipoString
	TipoString retorno;
	strcpy(retorno.string, ""); //seto um flag de retorno
	int tam = strlen(str);
	int i;
	if(tam>50){ //valida o tamanho da string informada
		printf("Tamanho inválido! Sua string pode ter, no máximo, 50 caracteres.\n");
		return retorno; //aqui, retorna uma string vazia que representa o null (já que não é possível retornar null na função do tipo TipoString)
	} else {
		for(i=0;i<tam;i++){
			if(!(str[i]>64 && str[i]<91)){	//valida se a string informada é composta de algo diferente dos caracteres maiúsculos de A a Z
				printf("String inválida!\n");
				return retorno;	//aqui, retorna uma string vazia que representa o null (já que não é possível retornar null na função do tipo TipoString)
			}
		}
	}
	strcpy(retorno.string, str); //se tudo estiver válido, o flag é sobrescrito pela string informada
	printf("String \"%s\", de %d caracteres, criada com sucesso!\n",str,tam);
	return retorno;	//a string informada é retornada
}

TipoString CriaStringVazia(){  //Cria um objeto do tipo TipoString vazio
	TipoString retorno;
	strcpy(retorno.string,"\0");	//atribui valor vazio a um objeto do tipo TipoString
	printf("String vazia criada com sucesso!\n");
	return retorno;	//retorna a string vazia
}

void ImprimeString(TipoString str){ //Imprime na tela um objeto do tipo TipoString
	if(!strcmp(str.string, "")) printf("String não foi criada corretamente ou é vazia.\n"); //caso a string informada seja inválida
	else printf("\"%s\"\n",str.string);	//imprime a string informada, caso seja válida
}

char GetChar(TipoString str, int i){ //Fornece um cacractere do objeto existente
	char retorno[50];	
	strcpy(retorno,str.string);	//cria uma cópia da string informada
	int tam = strlen(retorno);	//cria uma variável com o tamanho da string
	if(i<0 || i>tam-1){			//se o índice for menor que 0 ou maior que o tamanho da string,
		printf("Índice \"%d\" inválido!\n",i); //diz que o índice é inválido e retorna o caractere "!"
		return '!';
	} else {
		printf("Caracter de índice \"%d\": \"%c\"\n",i,retorno[i]);
		return retorno[i];	//retorna o caractere desejado
	}
}

int SetChar(TipoString *str, int i, char c){ //Altera um caractere do objeto existente
	if(!(c>64 && c<91)){	//Verifica se o caractere informado é válido
		printf("Caractere \"%c\" inválido!\n",c);
		return 1;
	}
	if((GetChar((TipoString) *str,i)) == '!'){	//verifica se o índice informado é válido
		printf("Posição \"%d\" inválida!\n",i);
		return 1;	//retorna 1 se a função não for realizada
	} else {
		printf("Caractere \"%c\" alterado para \"%c\"\n",(*str).string[i],c);
		(*str).string[i] = c;	//seta a string na posição solicitada com o valor informado
		return 0;	//retorna 1 se a função for realizada
	}
}

int GetTamanho(TipoString str){ //Fornece o tamanho do objeto
	int tam = strlen(str.string);
	return tam;	//retorna o tamanho da string informada
}

int InsereChar(TipoString *str, char c){ //Insere um caractere no fim o objeto
	int i = GetTamanho((TipoString)*str);
	if(!(c>64 && c<91)){
		printf("Você está tentando inserir um caractere inválido!\n");
		return 1;	//retorna 1 em caso de inserção inválida
	}
	if(i >= 50){
		printf("String já possui 50 caracteres!\n");
		return 1;	//retorna 1 se a string já estiver em seu tamanho máximo
	} else {
		printf("Caractere \"%c\" inserido com sucesso!\n",c);
		(*str).string[i]=c;	//insere o caractere informado no fim da string
		(*str).string[i+1] = '\0';	//insere um terminador de string após cada inserção, a fim de evitar interferência de lixos da memória
		return 0;	//retorna 0 caso a função tenha sido executada com sucesso
	}
}
