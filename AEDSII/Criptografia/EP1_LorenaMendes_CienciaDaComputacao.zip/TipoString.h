#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct TipoString{
	char string[50];
} TipoString;

TipoString CriaString(char *str);

TipoString CriaStringVazia();

void ImprimeString(TipoString str);

char GetChar(TipoString str, int i);

int GetTamanho(TipoString str);

int SetChar(TipoString *str, int i, char c);

int InsereChar(TipoString *str, char c);
