#include <stdlib.h>
#include <stdio.h>

#include "TipoLista.h"

#define DEBUG 0

celula * InsereDepois(celula * atual, int valor, int *tamanho){
	celula * nova;	//cria um objeto do tipo célula
	if(atual == NULL){	//se a lista estiver vazia, cria uma nova
		nova = malloc(sizeof(celula));
		nova->prox = nova;	//se é a primeira, aponta para ela mesma
		nova->ant = nova;
		nova->val = valor;
	} else {
		nova = malloc(sizeof(celula));	//aloca a nova célula
		nova->prox = atual;		//configura a nova célula para apontar para a(s) existente(s)
		nova->ant = atual->ant;
		nova->val = valor;

		celula * anterior;	//configura as células que já existiam para apontarem para a nova
		anterior = atual->ant;
		anterior->prox = nova;
		atual->ant = nova;
	}
	(*tamanho)++;	//incrementa o número de células da lista
	return nova;	//retorna a nova célula criada para ser o "apontador" para a lista
}

celula * InsereAntes(celula * atual, int valor, int *tamanho){
	celula * nova;	//cria um objeto do tipo célula
	if(atual == NULL){	//se a lista estiver vazia, cria uma nova
		nova = malloc(sizeof(celula));
		nova->prox = nova;
		nova->ant = nova;
		nova->val = valor;
	} else {
		nova = malloc(sizeof(celula));
		nova->prox = atual->prox;	//configura a nova célula para apontar para a(s) existente(s)
		nova->ant = atual;
		nova->val = valor;

		celula * seguinte;	//configura as células que já existiam para apontarem para a nova
		seguinte = atual->prox;
		seguinte->ant = nova;
		atual->prox = nova;
	}
	(*tamanho)++;	//incrementa o número de células da lista
	return nova;	//retorna a nova célula criada para ser o "apontador" para a lista
}

celula * Remove(celula * atual, int *tamanho){
	if(atual == NULL) {
            if(DEBUG) printf("[DEBUG] Lista vazia! Impossivel remover.\n");
            return NULL;
	}
	else if((*tamanho) == 1){	//se a lista só tiver um elemento,
		atual = NULL;	//aponta para null
		(*tamanho) --;	//decrementa o tamanho
		return NULL;
	} else {
		if((*tamanho) == 1){
			if(DEBUG) printf("[DEBUG] Agora tamanho é %d\n",(*tamanho));
			return atual;
		}
		celula * anterior = atual->ant;		//atualiza os ponteiros para anterior e seguinte na lista
		celula * seguinte = atual->prox;
		anterior->prox = seguinte;
		seguinte->ant = anterior;
		(*tamanho)--;
		if(DEBUG) printf("[DEBUG] Decrementei o tamanho. agora é %d\n",(*tamanho));
		return anterior;
	}
}

celula * Proxima(celula * atual){	//torna atual a música seguinte
	if(atual == NULL) return atual;
	else return atual->prox;
}

celula * Anterior(celula * atual){	//torna atual a música anterior
	if(atual == NULL) return atual;
	else return atual->ant;
}

celula * Limpa(celula * atual, int *tamanho){
	if(DEBUG) printf("[DEBUG] Limpando lista...\n");
	int i;
	int tam = (*tamanho);
	for(i=0;i<tam;i++){
            if(DEBUG) printf("[DEBUG] Tamanho: %d\n",(*tamanho));
            if ((*tamanho) == 0) break;
            atual = Remove(atual,tamanho);	//chama a função de remover enquanto a lista não acabar
            if(DEBUG) printf("[DEBUG] Musica removida. Tamanho é %d\n",(*tamanho));
	}
	return atual;
}
