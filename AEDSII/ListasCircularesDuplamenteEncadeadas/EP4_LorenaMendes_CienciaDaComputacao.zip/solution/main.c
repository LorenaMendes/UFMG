#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "TipoLista.h"

#define DEBUG 1

void imprimeLista(FILE * output, celula * lista) {  //função para imprimir a lista
	if(lista == NULL) {    //se a lista estiver vazia, imprime uma quebra de linha
            if(DEBUG) printf("[DEBUG] Lista vazia.\n");
            fprintf(output,"\n");
            return;
	}
	celula * temp = lista; //cria uma célula temporária com todo o conteúdo de lista
	printf("Lista: ");
	do {
            fprintf(output,"%d ",temp->val);    //imprime o id do objeto enquanto não "acabar" a lista
            printf("%d ",temp->val);
            temp = temp->prox;
	} while (temp != lista);
	fprintf(output,"\n");  //imprime uma quebra de linha ao terminar
	printf("\n");
}

void processaComando(FILE *file, FILE *output) {
	
    FILE *temp;
    char id[100], c;
    int id_int,posicao = 0;
    int tamanho = 0;
    celula * atual = NULL;
	

    while(c != EOF) //enquando o arquivo não termina,
    {
		c = getc(file);   //pega um caractere do arquivo
        switch(c) {     //analisa a qual função ele se refere
        case 'A':
            temp = file;
            c = getc(temp);     //cria uma variável temporária para não deslocar no arquivo original
            do {
				id[posicao] = c;   
				posicao++;
				c = getc(temp);
			} while (c >= 48 && c <= 57);    //percorre, pegando o valor do parâmetro, até achar um novo comando
			id[posicao] = '\0';
			posicao = 0;
			id_int = atoi(id);
            fseek(file,-1,SEEK_CUR);    //volta uma posição (pois, nesse momento, ele para no novo comando). Da próxima vez que usar o getc, ele pega o elemento seguinte, então o comando é "pulado"
            if(DEBUG) printf("[DEBUG] After, %d\n",id_int);
            atual = InsereAntes(atual,id_int,&tamanho);
            break;
        case 'B':
            temp = file;
            c = getc(temp);
            do {
				id[posicao] = c;
				posicao++;
				c = getc(temp);
				} while (c >= 48 && c <= 57);
			id[posicao] = '\0';
			posicao = 0;
			id_int = atoi(id);
            fseek(file,-1,SEEK_CUR);
            if(DEBUG) printf("[DEBUG] Before, %d\n",id_int);
            atual = InsereDepois(atual,id_int,&tamanho);
            break;
        case 'C':
			if(DEBUG) printf("[DEBUG] CLEAR.\n");
			atual = Limpa(atual,&tamanho);   //limpa a lista
            break;
        case 'D':
			if(DEBUG) printf("[DEBUG] DELETE.\n");
			atual = Remove(atual, &tamanho);     //remove o elemento atual
            break;
        case 'N':
			if(DEBUG) printf("[DEBUG] NEXT.\n");
			atual = Proxima(atual);      //vai para a próxima música
            break;
        case 'P':
			if(DEBUG) printf("[DEBUG] PREVIOUS.\n");
			atual = Anterior(atual);     //vai para a música anterior
            break;
        case '\n':
			if(DEBUG) printf("[DEBUG] LINEBREAK.\n");
            imprimeLista(output, atual);    //quando chegar no fim de uma linha, imprime o resultado dos comandos
            atual = Limpa(atual,&tamanho);  //limpa a lista para começar uma nova
            printf("\n");
            break;
        case EOF:
			break;
        default:    //isso filtra o caso de um caractere inválido ou parâmetro onde não deve ter parâmetro
            if(DEBUG) printf("[DEBUG] Caractere invalido: %c\n",c);
            break;
        }
    }

    fclose(output);
    return;
}

int main(int argc, char *argv[]) {

    printf("Argumentos: %d.\n------------------\n",argc);
    for(int i=0;i<argc;i++) printf("Argumento %d: %s\n",i,argv[i]); //mostra o número de argumentos informados.
    printf("\n");
    if(argc != 3) { //se forem informados mais ou menos que 2 argumentos, dá uma mensagem de erro.
        printf("ERRO DE INPUT!\nDigite o nome do arquivo de entrada e o nome do arquivo de saída!\n");
        return 0;
    }

	
	if(DEBUG) printf("[DEBUG] Comecei\n");
    FILE *file;
    
    file = fopen(argv[1], "r");     //abre o arquivo para leitura
    if(file == NULL){
    	printf("Erro ao abrir o arquivo.\n");
    	return 0;
    }

    FILE *output;
    output = fopen(argv[2], "w");    //abre o arquivo para escrita
    if(output == NULL){
        printf("Erro ao abrir o arquivo.\n");
        return 0;
    }

    if(DEBUG) printf("[DEBUG] Abri o arquivo\n");
    if(file) {
			if(DEBUG) printf("[DEBUG] Processando arquivo...\n");
            processaComando(file,output);       //começa a ler o arquivo e chama a função para interpretar os comandos
            if(DEBUG) printf("[DEBUG] Processei.\n");
            fclose(file);
    }

	return 0;
}
