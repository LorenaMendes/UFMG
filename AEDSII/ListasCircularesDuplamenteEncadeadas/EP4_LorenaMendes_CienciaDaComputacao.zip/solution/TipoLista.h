#ifndef TipoLista_include
#define TipoLista_include

typedef struct celula {
    int val;
    struct celula * prox;
    struct celula * ant;
} celula;

celula * InsereAntes(celula * atual, int valor, int *tamanho);
celula * InsereDepois(celula * atual, int valor, int *tamanho);
celula * Remove(celula * atual, int *tamanho);
celula * Proxima(celula * atual);
celula * Anterior(celula * atual);
celula * Limpa(celula * atual, int *tamanho);

#endif
