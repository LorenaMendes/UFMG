from random import randrange

amount = 1990
max_size = 40

for i in range(amount):
    final = ""
    id = 1
    size = randrange(max_size) + 1
    for j in range(size):
        command = randrange(6) + 1
        if command == 1:
            final += "A" + str(id)
            id += 1
        elif command == 2:
            final += "B" + str(id)
            id += 1
        elif command == 3:
            final += "D"
        elif command == 4:
            final += "N"
        elif command == 5:
            final += "P"
        else:
            final += "C"
    print(final)
