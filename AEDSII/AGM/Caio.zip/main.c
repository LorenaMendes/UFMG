#include <stdlib.h>
#include <stdio.h>
#include "Grafo.h"

//ordena o vetor de acorco com o peso das arestas
void Ordena(struct GrafoAresta * vetor_de_arestas, int numero_a) {
	if (!numero_a) return;
	int w;
	//auxiliar do tipo GrafoAresta
	struct GrafoAresta temp;
	for (int i = 1; i < numero_a; i++) {
		temp = vetor_de_arestas[i];
		//faz as trocas necessárias para ordenar
		for (w = i - 1; w >= 0 && temp.valor < vetor_de_arestas[w].valor; w--) vetor_de_arestas[w + 1] = vetor_de_arestas[w];
		vetor_de_arestas[w + 1] = temp;
	}
}

//passa os dados da lista de adjacências para um vetor
void ConverteListaEmVetor(struct GrafoVertice * lista_de_adjacencias, int numero_v, struct GrafoAresta * lista_para_imprimir){
	int i, count = 0;
	for (i = 0; i < numero_v; i++){
		lista_de_adjacencias[i].visitado = 1;
		struct GrafoVertice * vertice_atual = lista_de_adjacencias[i].seg;
		//enquanto ainda houver célula apontada, faz o procedimento
		while(vertice_atual){
			//caso o vértice correspondente ainda não tenha sido visitado, adiciona ao vetor
			if(lista_de_adjacencias[vertice_atual->id].visitado == 0){
				lista_para_imprimir[count].valor = vertice_atual->valor;
				lista_para_imprimir[count].vertice_a = i;
				lista_para_imprimir[count].vertice_b = vertice_atual->id;
				count++;
			}
			vertice_atual = vertice_atual->seg;
		}
	}
}

int main(int argc, char const *argv[]) {
	const char * arquivo1 = argv[1];
	const char * arquivo2 = argv[2];
	//abre o arquivo de leitura
	FILE * leitura = fopen(arquivo1, "r");

	int numero_v;
	int numero_a;

	//lê a primeira linha do arquivo com num de arestas e de vértices]
	fscanf(leitura, "%d %d", &numero_v, &numero_a);

	//lê cada linha seguinte com os componentes de cada aresta
	struct GrafoAresta vetor_de_arestas[numero_a];
	for (int i = 0; i < numero_a; i++) {
		fscanf(leitura, "%d ", &vetor_de_arestas[i].vertice_a);
		fscanf(leitura, "%d ", &vetor_de_arestas[i].vertice_b);
		fscanf(leitura, "%d ", &vetor_de_arestas[i].valor);
	}

	//ordena as arestas por seu valor
	Ordena(vetor_de_arestas, numero_a);

	//cria uma lista de adjacências
	struct GrafoVertice lista_de_adjacencias[numero_v];
	for (int i = 0; i < numero_v; i++) {
		lista_de_adjacencias[i].id = i;
		lista_de_adjacencias[i].seg = NULL;
	}

	//adiciona os vértices do vetor de arestas na lista de adjacências
	int cont = 0;
	for (int i = 0; i < numero_a; i++){
		if (AdicionaNaLista(vetor_de_arestas[i], numero_a, lista_de_adjacencias, numero_v)){
			//incrementa o contador a cada vez que uma aresta for adicionada
			cont++;
		}
	}

	//transforma a lista de adjacências em um vetor para facilitar a escrita no arquivo de saída
	struct GrafoAresta lista_para_imprimir[cont];
	ConverteListaEmVetor(lista_de_adjacencias, numero_v, lista_para_imprimir);

	fclose(leitura);

	//abre um arquivo no modo de escrita
	FILE * escrita = fopen(arquivo2, "w");
	
	//escreve a representação da árvore geradora mínima no arquivo
	fprintf(escrita, "%d %d\n", numero_v, cont);
	for (int i = 0; i < cont; ++i){
		fprintf(escrita, "%d %d %d\n", lista_para_imprimir[i].vertice_a, lista_para_imprimir[i].vertice_b, lista_para_imprimir[i].valor);
	}
	fclose(escrita);
	return 0;
}