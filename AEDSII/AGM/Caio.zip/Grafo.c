#include <stdio.h>
#include <stdlib.h>
#include "Grafo.h"

//coloca arestas na lista de adjacências (representada por vértices)
int AdicionaNaLista(struct GrafoAresta aresta, int numero_a, struct GrafoVertice * lista_de_adjacencias, int numero_v){
	//só insere se os dois vértices não estiverem previamente conectados
	int pesquisa = FazBuscaEmProfundidade(lista_de_adjacencias, aresta.vertice_a, aresta.vertice_b);
	for (int i = 0; i < numero_v; ++i) lista_de_adjacencias[i].visitado = 0;
	if(!pesquisa){
		Insere(lista_de_adjacencias, aresta.vertice_a, aresta.vertice_b, aresta.valor);
		Insere(lista_de_adjacencias, aresta.vertice_b, aresta.vertice_a, aresta.valor);
		return 1;
	} else return 0;
}

//utiliza algoritmo de BFS para ver se um vértice está direta ou indiretamente conectado a outro
int FazBuscaEmProfundidade(struct GrafoVertice * lista_de_adjacencias, int vertice_a, int vertice_b){
	int pesquisa = 0;
	if(lista_de_adjacencias[vertice_a].visitado) return 0;
	lista_de_adjacencias[vertice_a].visitado = 1;
	if(lista_de_adjacencias[vertice_a].seg == NULL) return pesquisa;
	struct GrafoVertice * vertice_atual = lista_de_adjacencias[vertice_a].seg;
	while(vertice_atual){
		if(vertice_atual->id == vertice_b) return 1;
		//busca recursivamente dentro de cada item da lista de adjacências
		else if(pesquisa = FazBuscaEmProfundidade(lista_de_adjacencias, vertice_atual->id, vertice_b)) return pesquisa;
		else vertice_atual = vertice_atual->seg;
	}
	return 0;
}

//insere um item na lista de adjacências
void Insere(struct GrafoVertice * lista_de_adjacencias, int vertice_a, int vertice_b, int valor){
	//auxiliares do tipo GrafoVertice
	struct GrafoVertice * vertice_ant;
	struct GrafoVertice * vertice_atual;
	struct GrafoVertice * inserido = malloc(sizeof(struct GrafoVertice));
	inserido->id = vertice_b;
	inserido->valor = valor;
	inserido->seg = NULL;
	//apontadores auxiliares
	vertice_ant = &lista_de_adjacencias[vertice_a];
	vertice_atual = lista_de_adjacencias[vertice_a].seg;
	while(vertice_atual){ //vai inserindo em ordem crescente
		if(vertice_b < vertice_atual->id){
			vertice_ant->seg = inserido;
			inserido->ant = vertice_ant;
			inserido->seg = vertice_atual;
			vertice_atual->ant = inserido;
			return;
		}
		vertice_ant = vertice_ant->seg;
		vertice_atual = vertice_atual->seg;
	}
	//chegou ao final e não conseguiu inserir: insere.
	vertice_ant->seg = inserido;
	inserido->ant = vertice_ant;
}