//representa uma aresta de um grafo
struct GrafoAresta
{
	int vertice_a;
	int vertice_b;
	int valor;
};

//representa um vértice de um grafo
struct GrafoVertice
{
	int visitado;
	struct GrafoVertice * seg;
	struct GrafoVertice * ant;
	int id;
	int valor;
};

//funções do TAD Grafo
void Insere(struct GrafoVertice * lista_de_adjacencias, int vertice_a, int vertice_b, int valor);
int FazBuscaEmProfundidade(struct GrafoVertice * lista_de_adjacencias, int vertice_a, int vertice_b);
int AdicionaNaLista(struct GrafoAresta aresta, int numero_a, struct GrafoVertice * lista_de_adjacencias, int numero_v);