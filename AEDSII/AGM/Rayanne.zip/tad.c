#include <stdio.h>
#include <stdlib.h>
#include "tad.h"


// FUNCAO AUXILIAR USADA PELO BUBBLESORT
void swap(Aresta *xp, Aresta *yp)
{
	Aresta temp = *xp;
	*xp = *yp;
	*yp = temp;
}

// IMPLEMENTACAO DE BUBBLESORT
void bubbleSort(Aresta arr[], int n)
{
	int i, j;
	for (i = 0; i < n - 1; i++)

		// ULTIMOS i ELEMENTOS JA ESTARAO NO LUGAR
		for (j = 0; j < n - i - 1; j++)
			if (arr[j].peso > arr[j + 1].peso)
				swap(&arr[j], &arr[j + 1]);
}

// FUNÇÃO QUE CRIA UM VERTICE COM TODOS OS VALORES DAQUELE QUE SERÁ ADICIONADO À LISTA
Vertice * CriaVertice(Vertice * lista_adjacencia, int peso, int adicionado) {
	//ALOCA UM VERTICE
	Vertice * vertice_a_adicionar = malloc(sizeof(Vertice));
	//DEFINE SEU FILHO
	vertice_a_adicionar->filho = NULL;
	//DEFINE SEU PAI
	vertice_a_adicionar->pai = NULL;
	//DEFINE O INDICADOR DE PESQUISA
	vertice_a_adicionar->val[0] = 0;
	//DEFINE SEU IDENTIFICADOR
	vertice_a_adicionar->val[1] = adicionado;
	//DEFINE SEU PESO COM RELAÇÃO AO DONO DA LISTA
	vertice_a_adicionar->val[2] = peso;

	return vertice_a_adicionar;
}

//ADICIONA O UM VERTICE NA LISTA DO DONO DA LISTA
int AdicionaVertice(Vertice * lista_adjacencia, int peso, int dono_lista, int adicionado) {

	//CRIA O VÉRTICE QUE SERÁ ADICIONADO À LISTA DO DONO DA LISTA
	Vertice * vertice_a_adicionar = CriaVertice(lista_adjacencia, peso, adicionado);

	// SE OCORRE DE ELE SER O PRIMEIRO A SER ADICIONADO, NÃO HÁ PREOCUPAÇÃO COM A ORDENAÇÃO
	if (lista_adjacencia[dono_lista].filho == NULL) {
		// ELE É ADICIONADO DIRETAMENTE
		lista_adjacencia[dono_lista].filho = vertice_a_adicionar;
		vertice_a_adicionar->pai = &lista_adjacencia[dono_lista];
		return 0;
	}

	//SAO CRIADOS APONTADORES AUXILIARES PARA ITERAÇÃO

	//APONTADOR AUXILIAR QUE APONTA PARA O DONO DA LISTA
	Vertice * auxiliar_2 = &lista_adjacencia[dono_lista];

	//APONTADOR AUXILIAR QUE APONTA PARA O FILHO DO DONO DA LISTA
	Vertice * auxiliar_1 = auxiliar_2->filho;

	//CAMINHA PELA LISTA ATÉ ENCONTRAR O LUGAR CORRETO E ORDENADO PARA INSERIR
	while (auxiliar_1) {

		if (auxiliar_1->val[1] <= vertice_a_adicionar->val[1]) {
			//SE NÃO FOR O LUGAR CERTO, OLHA PARA O PRÓXIMO
			auxiliar_1 = auxiliar_1->filho;
			auxiliar_2 = auxiliar_2->filho;

		} else {
			//FAZ AS TROCAS NECESSÁRIAS PARA INSERIR DE MANEIRA ORDENADA
			auxiliar_1->pai->filho = vertice_a_adicionar;

			//O PAI APONTA PARA O PAI DO AUXILIAR1
			vertice_a_adicionar->pai = auxiliar_1->pai;

			//O FILHO APONTA PARA O AUXILIAR1
			vertice_a_adicionar->filho = auxiliar_1;

			//O FILHO DO AUXILIAR1 PASSA A SER O ADICIONADO
			auxiliar_1->pai = vertice_a_adicionar;
			return 0;

		}
	}

	// NESTE PONTO, NÃO FOI NECESSARIO INSERIR ORDENADO, JA QUE O ADICIONADO É O MAIOR DE TODOS
	auxiliar_2->filho = vertice_a_adicionar;
	vertice_a_adicionar->pai = auxiliar_2;

	//DEFINE O FILHO COMO NULL
	vertice_a_adicionar->filho = NULL;
	return 0;
}

//DESCOBRE, RECURSIVAMENTE, SE DÁ PRA ENCONTRAR UM VERTICE A PARTIR DE OUTRO
int ProcuraVertice(struct Vertice * lista_adjacencia, int buscado, int dono_lista) {

	//PRIMEIRAMENTE, CHECA-SE SE O VERTICE JA FOI ENCONTRADO NA RECURSÃO
	//ISSO EVITA QUE O PROGRAMA ENTRE EM LOOP NESSA BUSCA

	if (lista_adjacencia[buscado].val[0] == 1) return 0;

	//SE CHEGOU NESSE PONTO, É PORQUE AINDA NÃO FOI ENCONTRADO, ENTÃO MARCO COMO ENCONTRADO
	lista_adjacencia[buscado].val[0] = 1;

	int valor_final = 0;

	//AUXILIAR 1 PERCORRE A LISTA EM BUSCA DO DONO DA LISTA
	Vertice * auxiliar_1 = lista_adjacencia[buscado].filho;

	if (!auxiliar_1) return valor_final;
	int i;

	while (auxiliar_1) {
		//SE ACHAR O VALOR, RETORNA 1
		if (auxiliar_1->val[1] == dono_lista) return 1;

		//SE NÃO ACHAR, FAZ A BUSCA NA LISTA DA CÉLULA ATUAL E RETORNA O QUE A FUNÇÃO RETORNAR
		else if (i =  ProcuraVertice(lista_adjacencia, auxiliar_1->val[1], dono_lista)) return i;

		//SE NÃO ACHAR, ANALISA O PRÓXIMO
		else auxiliar_1 = auxiliar_1->filho;
	}
	return 0;
}