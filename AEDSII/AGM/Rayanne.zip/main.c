#include <stdio.h>
#include <stdlib.h>
#include "tad.h"

int main(int argc, char const *argv[]) {

	// DECLARACOES DE VARIAVEIS NAO-LOCAIS
	FILE *input, *output;
	int header[2], v[2], peso, cont;

	// CHECANDO SE PARAMETROS ESTAO OK
	if (argc < 3) {
		printf("Erro! Quantidade de parametros insuficiente. Uso:\n\t%s <<input>> <<output>>\n", argv[0]);
		return 1;
	}

	// LE INPUT E ABORTA EM CASO DE ERRO
	input = fopen(argv[1], "r+");

	if (!input) {
		printf("Erro no arquivo de INPUT. Certifique-se de que o arquivo existe:\n%s\n", argv[1]);
		return 1;
	}

	// CARREGAMENTO DOS DADOS DO ARQUIVO DE INPUT
	// PARA A MEMORIA E CRIACAO DAS ESTRUTURAS DO T.A.D.
	fscanf(input, "%d %d", &header[0], &header[1]);
	Aresta vetor[header[1]];
	for (int cont = 0; cont < header[1]; cont++) {
		fscanf(input, "%d %d %d\n", &v[0], &v[1], &peso); // le vertice 0 da linha do arquivo
		// fscanf(input, "%d", &v[0]); // le vertice 0 da linha do arquivo
		// fscanf(input, "%d", &v[1]); // le vertice 1 da linha do arquivo
		// fscanf(input, "%d", &peso); // le peso da linha do arquivo
		vetor[cont].v[0] = v[0]; // guarda vertice 0
		vetor[cont].v[1] = v[1]; // guarda vertice 1
		vetor[cont].peso = peso; // guarda peso
	}
	fclose(input); // fecha o arquivo depois de processar

	// CRIACAO DOS VERTICES COM BASE NA LISTA DE ADJACENCIA JA ORDENADA
	Vertice lista_adjacencia[header[0]];
	bubbleSort(vetor, header[1]); // Arestas devem estar ordenadas
	for (int i = 0; i < header[0]; ++i) {
		lista_adjacencia[i].filho = 0;	// vertice inicialmente sem filho
		lista_adjacencia[i].val[0] = 0; // vertice visitado = NAO
		lista_adjacencia[i].val[1] = i; // rotulo do Vertice = i
		lista_adjacencia[i].val[2] = 0; // peso do Vertice = 0
	}

	///////////////////////////////////////////////////////////////////////
	/// NECESSARIO MODIFICAR LOGICA DAQUI PRA BAIXO
	///////////////////////////////////////////////////////////////////////

	cont = 0;
	for (int i = 0; i < header[1]; ++i) {
		if (ProcuraVertice(lista_adjacencia, vetor[i].v[0], vetor[i].v[1]))
			//VOLTA O VAL PARA 0
			for (int j = 0; j < header[0]; ++j) lista_adjacencia[j].val[0] = 0;
		else {
			//VOLTA O VAL PARA 0
			for (int j = 0; j < header[0]; ++j) lista_adjacencia[j].val[0] = 0;
			//CONTADOR DE ITENS DA LISA DE ADJACÊNCIAS
			cont ++;
			//NECESSÁRIO ADICIONAR NA LISTA DOS DOIS
			//INSERÇÃO DE ITENS NA LISTA DE ADJACÊNCIAS
			AdicionaVertice(lista_adjacencia, vetor[i].peso, vetor[i].v[0], vetor[i].v[1]);
			//ADICIONO NA LISTA DO SEGUNDO
			AdicionaVertice(lista_adjacencia, vetor[i].peso, vetor[i].v[1], vetor[i].v[0]);
		}
	}

	Aresta vetor_para_output[cont];
	int i2 = 0;
	for (int i = 0; i < header[0]; ++i) {
		//AUXILIAR QUE PERCORRE A LISTA PARA FORMAR O VETOR FINAL
		Vertice * temp1 = lista_adjacencia[i].filho;

		lista_adjacencia[i].val[0] = 1;

		while (temp1) {
			if (lista_adjacencia[temp1->val[1]].val[0] == 0) {
				vetor_para_output[i2].v[0] = i;
				vetor_para_output[i2].v[1] = temp1->val[1];
				vetor_para_output[i2].peso = temp1->val[2];
				i2++;
			}
			//PERCORRENDO A LISTA
			temp1 = temp1->filho;
		}
	}

	// ALOCACAO DO ARQUIVO DE OUTPUT
	output = fopen(argv[2], "w+");

	// DESCARGA DOS DADOS DA MEMORIA PARA O ARQUIVO DE OUTPUT
	// (ABORTA EM CASO DE ERRO NA ALOCACAO DO ARQUIVO)
	if (!output) {
		printf("Erro no arquivo de OUTPUT. Impossivel utilizar este caminho:\n%s\n", argv[2]);
		return 1;
	}

	fprintf(output, "%d %d\n", header[0], cont);
	for (int i = 0; i < cont; ++i) {
		fprintf(output, "%d ", vetor_para_output[i].v[0]); //IMPRIME VERTICE 0 NO ARQUIVO DE OUTPUT
		fprintf(output, "%d ", vetor_para_output[i].v[1]); //IMPRIME VERTICE 1 NO ARQUIVO DE OUTPUT
		fprintf(output, "%d\n", vetor_para_output[i].peso); //IMPRIME PESO NO ARQUIVO DE OUTPUT
	}

	//FECHA O ARQUIVO DE OUTPUT
	fclose(output);

	return 0;
}
