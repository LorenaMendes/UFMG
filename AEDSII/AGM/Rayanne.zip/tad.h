#ifndef TAD
#define TAD

//ESTRUTURAS DO TAD - VÉRTICE
typedef struct Vertice {
	struct Vertice * pai;
	struct Vertice * filho;
	int val[3]; // valores do vertice: flag se ja foi visitado, rotulo do Vertice, peso do Vertice;
} Vertice;

//ESTRUTURAS DO TAD - ARESTA
typedef struct Aresta {
	int v[2]; // vertices da aresta
	int peso;
} Aresta;


// FUNÇÕES DO TAD
void swap(struct Aresta *xp, struct Aresta *yp);
void bubbleSort(struct Aresta arr[], int n);
Vertice * CriaVertice(Vertice * lista_adjacencia, int peso, int adicionado);
int AdicionaVertice(struct Vertice * lista_adjacencia, int peso, int dono_lista, int adicionado);
int ProcuraVertice(struct Vertice * lista_adjacencia, int dono_lista, int buscado);

#endif
