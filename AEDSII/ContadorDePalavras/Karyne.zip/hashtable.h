#ifndef HASHTABLE
#define HASHTABLE

struct par_hashtable_interno {
	char *chave;
	int valor;
	int contador;
	struct par_hashtable_interno *prox;
};

typedef struct par_hashtable_interno par_hashtable;

struct hashtable_interno {
	int n_elementos;
	struct par_hashtable_interno **valores;	
};

typedef struct hashtable_interno tabela_hashtable;

tabela_hashtable *nova_hashtable( int n_elementos );
int funcao_hash( tabela_hashtable *tabela, char *chave );
par_hashtable *nova_entrada_hashtable( char *chave, int valor );
void inserir_hashtable( tabela_hashtable *tabela, char *chave, int valor );
int busca_hashtable( tabela_hashtable *tabela, char *chave ) ;

#endif