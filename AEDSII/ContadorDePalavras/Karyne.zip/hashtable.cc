#include <stdlib.h>
// #include <stdio.h>
#include <string.h>
#include <limits.h>	// Datatype:	ULONG_MAX
#include "hashtable.h"

/* Construtor da HASHTABLE */
tabela_hashtable *nova_hashtable(int n_elementos) {
	tabela_hashtable *tabela = 0;

	/* Alocacao da tabela */
	if((tabela = (tabela_hashtable*) malloc(sizeof(tabela_hashtable))) == 0 ) return 0;

	/* Alocacao dos ponteiros de cabecalho */
	if(n_elementos>=1) {
		if((tabela->valores = (par_hashtable**) malloc(sizeof(par_hashtable*)*n_elementos)) == 0 ) return 0;
	} else return 0;

	/* Se estiver tudo certo com a tabela, aloco os valores */
	tabela->n_elementos = n_elementos;
	for(int i = 0; i < n_elementos; i++ ) tabela->valores[i] = 0;

	return tabela;
}

/* Calcula chave para tabela HASHTABLE */
int funcao_hash( tabela_hashtable *tabela, char *chave ) {
// int ht_hash( hashtable_t *hashtable, char *key ) {
	unsigned long int random;
	int i = 0;

	while( random < ULONG_MAX && i < (signed) strlen( chave ) ) {
		random = random << 10;
		random += chave[ i ];
		i++;
	}

	return random % tabela->n_elementos;
}

/* Cria um par chave-valor */
par_hashtable *nova_entrada_hashtable( char *chave, int valor ) {
	par_hashtable *newpair;

	if( ( newpair = (par_hashtable*) malloc( sizeof( par_hashtable ) ) ) == 0 ) return 0;

	if( ( newpair->chave = strdup( chave ) ) == 0 )	return 0;

	newpair->valor = valor;
	newpair->contador = 1;
	newpair->prox = 0;

	return newpair;
}

/* Insere um par chave-valor na Hashtable */
void inserir_hashtable( tabela_hashtable *tabela, char *chave, int valor ) {
	int chave_hash = 0;
	par_hashtable *novo = 0;
	par_hashtable *prox = 0;
	par_hashtable *ant = 0;

	chave_hash = funcao_hash( tabela, chave );
	// printf("hash de %s: %d \n",chave,chave_hash);
	prox = tabela->valores[ chave_hash ];

	while( prox != 0 && prox->chave != 0 && strcmp( chave, prox->chave ) > 0 ) {
		ant = prox;
		prox = prox->prox;
	}

	/* Chave ja contem registro. Vamos somente incrementar o contador */
	if( prox != 0 && prox->chave != 0 && strcmp( chave, prox->chave ) == 0 ) {

		/* Incrementa o contador */
		prox->contador++;
		/* if(DEBUG) 
		//	printf("Incrementando o contador de %s: %d ocorrencias\n",prox->chave,prox->contador); 
		/*/

	/* Chave nao contem nenhum registro. Vamos inserir diretamente na chave.*/
	} else {
		novo = nova_entrada_hashtable( chave, valor );

		/* Se estamos no inicio da lista encadeada, ajustar so o proximo elemento */
		if( prox == tabela->valores[ chave_hash ] ) {
			novo->prox = prox;
			tabela->valores[ chave_hash ] = novo;
	
		/* Se estamos no final da lista encadeada, ajustar so o elemento anterior */
		} else if ( prox == 0 ) {
			ant->prox = novo;
	
		/* Caso contrario, se nem no inicio e nem no final...
		// ...entao, necessario ajustar ambos elementos: proximo e anterior
		/*/
		} else  {
			novo->prox = prox;
			ant->prox = novo;
		}
	}
}

/* Encontra um par chave-valor dentro da hashtable */
int busca_hashtable( tabela_hashtable *tabela, char *chave ) {
	int chave_hash = 0;
	par_hashtable *pair;

	chave_hash = funcao_hash( tabela, chave );

	/* Procurando o valor */
	pair = tabela->valores[ chave_hash ];
	while( pair != 0 && pair->chave != 0 && strcmp( chave, pair->chave ) > 0 ) {
		pair = pair->prox;
	}

	/* Caso nao encontrado, retorna 0 */
	if( pair == 0 || pair->chave == 0 || strcmp( chave, pair->chave ) != 0 ) {
		return 0;
	/* Se encontrado, retorna o valor */
	} else {
		return pair->contador;
	}
	
}