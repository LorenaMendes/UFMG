#define _XOPEN_SOURCE 500 // Ativa certas funcoes de biblioteca (strdup) on linux.

#include <stdio.h> 	// Biblioteca basica
#include <stdlib.h>	// Funcoes: 	malloc, qsort, etc.
#include <string.h>	// Funcoes: 	strlen, strcmp, strdup, strcpy
#include "hashtable.h"
#include "sorts.h"
#include "sequencial.h"

int main( int argc, char **argv ) {
	int tamanho_hash = 262144;
	tabela_hashtable *hashtable = nova_hashtable( tamanho_hash );
	registro *vetor_sequencial = NULL;
	int algoritmo_ord = -1, tipo_pesq = -1;
	int tam;
	int tamanho_pedaco_arquivo = letras_palavra * 100;
	char * pedaco_arquivo = (char*) malloc (tamanho_pedaco_arquivo); // variavel que armazena uma linha do arquivo
	char ** palavras = (char**) malloc (sizeof(char*) * 1000000);
	// char ** palavras = (char**) malloc (1000000 * sizeof(char *));
	char temp[100] = "\n";
	FILE * entrada;
	FILE * saida;

	entrada = fopen(argv[1], "r");
	saida = fopen(argv[4], "w");

	if((atoi(argv[2]) >= 0) || (atoi(argv[2]) <= 1)) {
		tipo_pesq = atoi(argv[2]);
	}
	if((atoi(argv[3]) >= 0) || (atoi(argv[3]) <= 1)) {
		algoritmo_ord = atoi(argv[3]);
	}
	if(tipo_pesq == -1 || algoritmo_ord == -1) {
		printf("Opcoes invalidas.\n");
		printf("Favor digitar conforme o exemplo:\n");
		printf("./tp3 {entrada} 1 1 {saida}\n");
		return 0;
	}

	if(entrada == NULL || saida == NULL) {
		printf("Arquivo de entrada e/ou saida impossivel(is) de alocar.\n");
		printf("Favor digitar conforme o exemplo:\n");
		printf("./tp3 {entrada} 0 0 {saida}\n");
		return 0;
	}

	/* Leitura dos registros do arquivo de entrada */
	printf("Lendo input do disco...\n");
	if(entrada == NULL) {
		printf("ERRO! arquivo nao encontrado.\n");
		return 1;
	}
	printf("Armazenando input...\n");
	for(int i=0; i<(tamanho_hash); i++) palavras[i] = (char*) malloc (letras_palavra * sizeof(char));

	tam = 0;
	// int linha_contador = 0;
	
	while(fgets(pedaco_arquivo, tamanho_pedaco_arquivo, entrada)){
		 // printf("linha %d. Palavras %d.",linha_contador++,tam);
			pontuacao_e_minusculas(pedaco_arquivo);
			
			char* token = strtok(pedaco_arquivo, " \n\0");
			for(;token;tam++) {
			    // printf("%d -- %s\n",tam,token);
			    strcpy(palavras[tam], token);

			    token = strtok(NULL, " \n\0");
			}
	}

	
	printf("Processando dados...\n");
	// se for HashTable
	if(tipo_pesq == 1) {
		for(int i=0; i<tam; i++) {
		    inserir_hashtable( hashtable, palavras[i], i );
		}
	} 

	// se for Pesquisa Sequencial
	else {
		for(int i=0; i<tam; i++) {
			if(vetor_sequencial == NULL) {
				vetor_sequencial = novo_registro(palavras[i]);
			}
			else {
				registro *tmp;
				if(strcmp(palavras[i],vetor_sequencial->palavra) == 0) {
						vetor_sequencial->count++;
				}

				for(tmp = vetor_sequencial;tmp->next != NULL;tmp = tmp->next) {
					if(strcmp(palavras[i],tmp->next->palavra) == 0) tmp->next->count++;
				}

				tmp->next = novo_registro(palavras[i]);				
			}
		}
	}

	/* Ordenacao */
	printf("Ordenando dados...\n");

	// Se algoritmo de ordenacao for Heapsort
	if(algoritmo_ord == 1) {
		mergesort (palavras, tam );
	} 
	// Ja se for selection sort
	else { 
		selection_sort (palavras, tam); 
	}

	/* Imprimindo */
	busca_hashtable( hashtable, palavras[0]);
	busca_hashtable( hashtable, palavras[0]);
	printf("Export para o arquivo...\n");
	if(tipo_pesq == 1) {
		for(int i=0;i<tam;i++) {
			if(strcmp(palavras[i],temp) != 0) {
				// printf("%s %d\n",palavras[i],busca_hashtable( hashtable, palavras[i]));
				fprintf(saida,"%s %d\n",palavras[i],busca_hashtable( hashtable, palavras[i]));
			}
			strcpy(temp,palavras[i]);
		}
	} else {
		for(int i=0;i<tam;i++) {
			if(strcmp(palavras[i],temp) != 0) {
				fprintf(saida,"%s %d\n",palavras[i],(busco_registro(palavras[i],vetor_sequencial))->count);
			}
			strcpy(temp,palavras[i]);
		}
	}

	fclose(entrada);
	fclose(saida);

	return 0;
}

