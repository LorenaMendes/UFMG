#include "sequencial.h"
#include <stdlib.h>	// Funcoes: 	malloc, qsort, etc.
#include <string.h>	// Funcoes: 	strlen, strcmp, strdup, strcpy

#define letras_palavra 60

registro *novo_registro(char* registro_in) {
	registro *temp = (registro*) malloc(sizeof(registro));

	// E seto seus valores
	temp->next = NULL;
	temp->palavra = (char*) malloc(letras_palavra * (sizeof(char)));
	strcpy(temp->palavra,registro_in);
	temp->count = 1;

	return temp;
}

registro* busco_registro(char* registro_in, registro *vetor_sequencial) {
	// Vou andando pela lista de registros pra ver se acho a palavra
	// printf("buscando %s...\n",palavra);
	for(registro *temp = vetor_sequencial;temp != NULL;temp = temp->next) {
		// printf("Comparando %s e %s...",palavra,temp->palavra);
		if(strcmp(temp->palavra,registro_in) == 0) {
			// printf(" iguais.\n");
			return temp;
		}
		// printf(" mas nao sao iguais.\n");
	}

	// se terminei a lista e nao achei nada, tem alguma coisa errada...
	// printf("ERRO! Palavra nao encontrada.\n");

	// retorno NULL e trato na funcao pai
	return NULL;
}