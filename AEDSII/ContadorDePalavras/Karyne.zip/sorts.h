#ifndef SORTS
#define SORTS

#define letras_palavra 60

void pontuacao_e_minusculas(char *p);

void mergesort_r(int left, int right, char *list[letras_palavra]);
void mergesort(char *list[100], int length);
void merge(char *list[100], int left_start, int left_end, int right_start, int right_end);

void selection_sort(char *arr[letras_palavra], int n) ;

#endif