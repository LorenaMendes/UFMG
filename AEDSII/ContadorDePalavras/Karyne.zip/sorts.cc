#include "sorts.h"
#include <string.h> // Funcoes:   strlen, strcmp, strdup, strcpy
#include <ctype.h>
// C++ program for implementation of Heap Sort 
#include <iostream> 



void pontuacao_e_minusculas(char *p)
{
    char *src = p, *dst = p;

    while (*src)
    {
       if (ispunct((unsigned char)*src))
       {
          /* Skip this character */
          src++;
       }
       else if (isupper((unsigned char)*src))
       {
          /* Make it lowercase */
          *dst++ = tolower((unsigned char)*src);
          src++;
       }
       else if (src == dst)
       {
          /* Increment both pointers without copying */
          src++;
          dst++;
       }
       else
       {
          /* Copy character */
          *dst++ = *src++;
       }
    }

    *dst = 0;
}

void mergesort_r(int left, int right, char *list[letras_palavra]) // Overloaded portion
{
    if (right - left <= 1)
    {
        return;
    }


    int left_start  = left;
    int left_end    = (left+right)/2;
    int right_start = left_end;
    int right_end   = right;


    mergesort_r( left_start, left_end, list);

    mergesort_r( right_start, right_end, list);


    merge(list, left_start, left_end, right_start, right_end);
}

void mergesort(char *list[letras_palavra], int length) // First part
{
    mergesort_r(0, length, list);
}

void merge(char *list[letras_palavra], int left_start, int left_end, int right_start, int right_end)
{

    int left_length = left_end - left_start;
    int right_length = right_end - right_start;


    char left_half[left_length][letras_palavra];
    char right_half[right_length][letras_palavra];

    int r = 0;
    int l = 0;
    int i = 0;


    for (i = left_start; i < left_end; i++, l++)
    {
        strcpy(left_half[l], list[i]);
    }


    for (i = right_start; i < right_end; i++, r++)
    {
        strcpy(right_half[r], list[i]);
    }


    for ( i = left_start, r = 0, l = 0; l < left_length && r < right_length; i++)
    {
        if ( strcmp(left_half[l], right_half[r])<0 ) 
        { strcpy(list[i], left_half[l++]); }
        else { strcpy(list[i], right_half[r++]); }
    }


    for ( ; l < left_length; i++, l++) { strcpy(list[i], left_half[l]); }
    for ( ; r < right_length; i++, r++) { strcpy(list[i], right_half[r]); }
}
  
// Sorts an array of strings where length of every 
// string should be smaller than letras_palavra 
void selection_sort(char *arr[letras_palavra], int n) 
{ 
    int i, j; 
   
    // One by one move boundary of unsorted subarray 
    char minStr[letras_palavra]; 
    for (i = 0; i < n-1; i++) 
    { 
        // Find the minimum element in unsorted array 
        int min_idx = i; 
        strcpy(minStr, arr[i]); 
        for (j = i+1; j < n; j++) 
        { 
            // If min is greater than arr[j] 
            if (strcmp(minStr, arr[j]) > 0) 
            { 
                // Make arr[j] as minStr and update min_idx 
                strcpy(minStr, arr[j]); 
                min_idx = j; 
            } 
        } 
   
        // Swap the found minimum element with the first element 
        if (min_idx != i) 
        { 
            char temp[letras_palavra]; 
            strcpy(temp, arr[i]); //swap item[pos] and item[i] 
            strcpy(arr[i], arr[min_idx]); 
            strcpy(arr[min_idx], temp); 
        } 
    } 
} 