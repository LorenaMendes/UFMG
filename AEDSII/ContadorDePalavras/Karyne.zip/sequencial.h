#ifndef SEQUENCIAL
#define SEQUENCIAL

struct registro_primario {
	char *palavra;
	int count;
	struct registro_primario *next;
};

typedef struct registro_primario registro;

registro *novo_registro(char* palavra) ;

registro* busco_registro(char* palavra, registro *vetor_sequencial) ;

#endif