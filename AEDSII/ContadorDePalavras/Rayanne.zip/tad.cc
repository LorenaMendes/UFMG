#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "tad.h"

#define MAX_LEN 1000

int funcaoHash(char *str) {
    unsigned long random = 5555, valor;

    while (!valor) {
        str += 1;
        valor = *str;
        random = valor + (random + (random << 5));
    }
    return random % HASHTABLE_TAMANHO;
}

ElementoHash *buscaHashtable (ElementoHash** hashtable_mapa, char *codigo) {
    unsigned long numero = funcaoHash(codigo);

    while (hashtable_mapa[numero]) {
        if (!strcmp(hashtable_mapa[numero]->codigo, codigo)) return hashtable_mapa[numero];
        numero = (numero + 1) % HASHTABLE_TAMANHO;
    }

    return 0;
}

void insereHashtable (ElementoHash** hashtable_mapa, char *chave, int valor) {
    int numero = funcaoHash(chave);

    while (hashtable_mapa[numero]) {
        if (!strcmp(hashtable_mapa[numero]->codigo, chave)) { hashtable_mapa[numero]->count++; return; }
        numero = (numero + 1) % HASHTABLE_TAMANHO;
    }

    hashtable_mapa[numero] = (ElementoHash*) malloc(sizeof(ElementoHash));
    hashtable_mapa[numero]->count = 1;
    hashtable_mapa[numero]->codigo = (char*) malloc( LENGTH_PALAVRA );
    strcpy(hashtable_mapa[numero]->codigo, chave);

    return;
}

int construtorHashtable (ElementoHash** hashtable_mapa) {
    for (int i = 0; i < HASHTABLE_TAMANHO; i++) hashtable_mapa[i] = 0;
    return 0;
}

int Procura(char * palavra, ItemSequencial * vetor, int tam) {
    for (int i = 0; i < tam; ++i)
        if (vetor[i].palavra == NULL || !(strcmp(vetor[i].palavra, palavra)))
            return i;
    return -1;
}

int strcmp_mudada(const void *a, const void *b) {
    char * valor1 = ((ItemSequencial *)a)->palavra;
    char * valor2 = ((ItemSequencial *)b)->palavra;
    return (strcmp(valor1, valor2));
}

void bubbleSort(ItemSequencial * arr, int max) {
    ItemSequencial * aux = (ItemSequencial*)malloc(sizeof(ItemSequencial));
    for (int j = 0; j < max - 1; j++) {
        // printf("ordenando %s\n",arr[j]);
        for (int i = j + 1; i < max; i++) {
            // printf("comparando %s com %s\n", arr[j].palavra, arr[i].palavra);
            if (strcmp(arr[j].palavra, arr[i].palavra) > 0) {

                //strcpy(aux->palavra, arr[j].palavra);
                aux->palavra = arr[j].palavra;
                aux->freq = arr[j].freq;

                //strcpy(arr[j].palavra, arr[i].palavra);
                arr[j].palavra = arr[i].palavra;
                arr[j].freq = arr[i].freq;

                // strcpy(arr[i].palavra, aux->palavra);
                arr[i].palavra = aux->palavra;
                arr[i].freq = aux->freq;
            }
        }
    }
}

void bubbleSortString(char * arr[LENGTH_PALAVRA], int max) {
    char * aux = (char*) malloc(LENGTH_PALAVRA);
    for (int j = 0; j < max - 1; j++) {
        for (int i = j + 1; i < max; i++) {
            // printf("comparando %s com %s\n", arr[j].palavra, arr[i].palavra);
            if (strcmp(arr[j], arr[i]) > 0) {

                strcpy(aux, arr[j]);
                strcpy(arr[j], arr[i]);
                strcpy(arr[i], aux);
            }
        }
    }
}

void trataLinha(char *p){
    char *src = p, *dst = p;
    while (*src){
        if (ispunct((unsigned char)*src)){
            /* Skip this character */
            src++;
        } else if (isupper((unsigned char)*src)){
            /* Make it lowercase */
            *dst++ = tolower((unsigned char) * src);
            src++;
        } else if (src == dst){
            /* Increment both pointers without copying */
            src++;
            dst++;
        } else *dst++ = *src++;
    } *dst = 0;
}