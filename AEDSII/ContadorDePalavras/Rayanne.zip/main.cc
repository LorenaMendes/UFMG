#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "tad.h"

int main( int argc, char **argv ) {
    if (argc < 5 || argc > 5) {
        printf("ABORTANDO EXECUCAO.\nPasse o arquivo de leitura, tipo de algoritmo [0 | 1], tipo de ordenacao [0 | 1] e arquivo de gravacao.\nPor exemplo:\n");
        printf("texto200.txt 1 1 arquivo.gravacao.txt\n");
        return -1;
    } 

    FILE * arquivoleitura = fopen(argv[1], "r");
    if (arquivoleitura == 0) {
        printf("ABORTANDO EXECUCAO! Arquivo de leitura incorreto.\n");
        return -4;
    } else if ((atoi(argv[2]) != 0) && (atoi(argv[2]) != 1)) {
        printf("ABORTANDO EXECUCAO.\nPara o tipo de algoritmo passe [0 | 1].\n");
        return -2;
    } else if ( (atoi(argv[3]) != 0) && (atoi(argv[3]) != 1)) {
        printf("ABORTANDO EXECUCAO.\nPara o tipo de ordenacao passe [0 | 1].\n");
        return -3;
    }


    int modo_pesquisa;
    int modo_ordenacao;
    if(atoi(argv[2]) == 0 && atoi(argv[3]) == 0) {modo_pesquisa = 1; modo_ordenacao = 1;}
    if(atoi(argv[2]) == 0 && atoi(argv[3]) == 1) {modo_pesquisa = 1; modo_ordenacao = 2;}
    if(atoi(argv[2]) == 1 && atoi(argv[3]) == 0) {modo_pesquisa = 2; modo_ordenacao = 1;}
    if(atoi(argv[2]) == 1 && atoi(argv[3]) == 1) {modo_pesquisa = 2; modo_ordenacao = 2;}

    
    char ** array_palavra = (char**) malloc (sizeof(char *) * 15 * 1024 * 1024 ); // suporta ate 1.5M palavras
    char * aux_palavra = (char*) malloc (100);
    char * aux_10palavras = (char*) malloc (1000); // suporta ate 1000 caracteres por linha

    printf("Entrando com arquivo de leitura\n");

    int QUANT_PAL = 0;

    while (fgets(aux_10palavras, 1000, arquivoleitura)) {

        trataLinha(aux_10palavras);

        aux_palavra = strtok(aux_10palavras, " \n");

        while (aux_palavra) {
            array_palavra[QUANT_PAL] = (char*) malloc(LENGTH_PALAVRA);
            strcpy(array_palavra[QUANT_PAL], aux_palavra);
            aux_palavra = strtok(0, " \n");
            QUANT_PAL++;
        }
    }

    printf("Total de palavras: %d\n",QUANT_PAL);


    fclose(arquivoleitura);
    free(arquivoleitura);
    free(aux_palavra);
    free(aux_10palavras);


    printf("Processando dados via ");

    FILE * out = fopen(argv[4], "w");

    switch(modo_pesquisa){
        case 1:  // Se for Pesquisa Sequencial
        {
            printf("item sequencial\n");
            ItemSequencial * array_sequencial = (ItemSequencial*) malloc(QUANT_PAL * sizeof(ItemSequencial));
            for (int i = 0; i < QUANT_PAL; ++i){
                array_sequencial[i].palavra = NULL;
                array_sequencial[i].freq = 0;
            }
            for (int i = 0; i < QUANT_PAL; ++i) {
                int index = Procura(array_palavra[i], array_sequencial, QUANT_PAL);
                array_sequencial[index].palavra = array_palavra[i];
                array_sequencial[index].freq++;
            }
            int SEQ_QUANT_PAL;
            for (int i = 0; i < QUANT_PAL; ++i) {
                if (!array_sequencial[i].palavra) {
                    SEQ_QUANT_PAL = i;
                    break;
                }
            }

            if (modo_ordenacao == 1) { // Se ordenacao for n^2
                printf("Fazendo ordenacao de custo O(n2) -- Bubble Sort \n");
                bubbleSort(array_sequencial, SEQ_QUANT_PAL);
            }
            if (modo_ordenacao == 2) { // Se ordenacao for log n
                printf("Fazendo ordenacao de custo O(log n) -- Quick Sort \n");
                qsort(array_sequencial, SEQ_QUANT_PAL, sizeof(ItemSequencial), strcmp_mudada);
            }
            for (int i = 0; i < SEQ_QUANT_PAL; ++i) {
                fprintf(out, "%s %d\n", array_sequencial[i].palavra, array_sequencial[i].freq);
            }
            break;
        }
        case 2: // Se for pesquisa HashTable
        {
            printf("hashtable\n");
            ElementoHash* hashtable_mapa[HASHTABLE_TAMANHO];
            construtorHashtable(hashtable_mapa);
            for ( int i = 0; i < QUANT_PAL; i++) insereHashtable(hashtable_mapa, array_palavra[i], i);

            if (modo_ordenacao == 1) bubbleSortString(array_palavra, QUANT_PAL);
            else qsort(array_palavra, QUANT_PAL, sizeof(char *), strcmp_mudada);


            char *ultima_palavra = (char *) malloc(100 * sizeof(char *));

            printf("Imprimindo %d palavras...\n",QUANT_PAL);

            ElementoHash *ultimo_item;

            for(int j=0;j<QUANT_PAL;j++) {
                ultimo_item = buscaHashtable(hashtable_mapa, array_palavra[j]);
                if(ultimo_item != NULL) if(strcmp(ultima_palavra,ultimo_item->codigo) != 0) fprintf(out, "%s %d\n",array_palavra[j],ultimo_item->count);
                if(ultimo_item != NULL) strcpy(ultima_palavra,ultimo_item->codigo);
            }

            break;
        }
    }

    return 0;
}