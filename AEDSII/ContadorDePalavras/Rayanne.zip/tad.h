#ifndef TAD_PARA_HASHTABLE_E_SEQUENCIAL
#define TAD_PARA_HASHTABLE_E_SEQUENCIAL

#define HASHTABLE_TAMANHO 100000
#define LENGTH_PALAVRA 60
// #define MAX_LEN 1000

typedef struct ItemSequencial {
	char * palavra;
	int freq;
}ItemSequencial;

struct ElementoHash {
    char * codigo;
    int count;
}typedef ElementoHash;

int funcaoHash(char *str);

ElementoHash *buscaHashtable (ElementoHash** hashtable_mapa, char *codigo);

void insereHashtable (ElementoHash** hashtable_mapa, char *codigo, int data);

int construtorHashtable (ElementoHash** hashtable_mapa);

int Procura(char * word, ItemSequencial * vetor, int tam);

int strcmp_mudada(const void *a, const void *b);

void bubbleSort(ItemSequencial * arr, int n);

void bubbleSortString(char *arr[LENGTH_PALAVRA], int n);

void trataLinha(char *p);

#endif