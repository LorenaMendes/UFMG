#define SIZE 100000 // tamanho da hashtable
#define MAX_LETRAS 60 // limite de letras por palavra
#define MAX_LEN 1000

struct DataItem {
    int data;
    char *key;
    int count;
}typedef DataItem;

typedef struct Seq {
	char * word;
	int count;
}Seq;

void Inicializa(Seq * vetor, int tam);
int BuscaSequencial(char * word, Seq * vetor, int tam);

DataItem *getValueByKey (DataItem** hashArray, char *key);
void putValueForKey (DataItem** hashArray, char *key, int data);
void initializeHashArray (DataItem** hashArray);

/*Funções para ordenação*/
int odenacao(const void *a, const void *b);
void selectionSort(Seq * arr, int n);
void selectionSortString(char *arr[MAX_LEN], int n);