#include "hashTable.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#define LOG 0
#define MAX_LEN 1000

int hashCode(char *str) {
    unsigned long hash = 5381;
    int c;

    while ((c = *str++) != 0)
        hash = ((hash << 5) + hash) + c; /* hash * 33 + c */

    return hash % SIZE;
}

/*
 By given key returns a pointer to a DataItem with the same key
 Input: Pointer to hashArray array, int key value
 Output: If key found - the pointer to a DataItem else NULL
*/
DataItem *getValueByKey (DataItem** hashArray, char *key) {
     /* Get the hash */
     unsigned long hashIndex = hashCode(key);  

     /* Move in array until an empty */
     while(hashArray[hashIndex] != NULL) {

        if(strcmp(hashArray[hashIndex]->key, key) == 0) {
           return hashArray[hashIndex]; 
       }

        /* Go to next cell */
        ++hashIndex;

        /* Wrap around the table */
        hashIndex %= SIZE;
     }

     return NULL;        
}

/*
 Adding a DataItem to a hashArray
 Input: Pointer to hashArray array, int key value, char* (string) data value
 Output: None
*/
void putValueForKey (DataItem** hashArray, char *key, int data) {
  	/* Get the hash */
    int hashIndex = hashCode(key);

    /* Move in array until an empty or deleted cell */
    /* Or until finds a repeated word */
    while(hashArray[hashIndex] != NULL) {
        if(strcmp(hashArray[hashIndex]->key,key) == 0) {
            // printf("\niguais!!\n");
            hashArray[hashIndex]->count++;
            if(LOG) printf("%s (%d) -- inserido na chave %d.\n",key,hashArray[hashIndex]->count,hashIndex);
            return;
        }
     	/* Go to next cell */
		++hashIndex;

		/* Wrap around the table */
		hashIndex %= SIZE;
    }
    if(LOG) printf("%s (1) -- inserido na chave %d.\n",key,hashIndex);

    /* if(strcmp(hashArray[hashIndex]->key,key) == 0) {
        hashArray[hashIndex]->count++;
        printf("count: %d.\n",hashArray[hashIndex]->count);
        return;
    }*/

    // printf("rodei loop.\n");

	/* Creates a new data item */
    hashArray[hashIndex] = (DataItem*) malloc(sizeof(DataItem));
    // printf("criei dataitem.\n");
    hashArray[hashIndex]->data = data;  
    hashArray[hashIndex]->key = (char*) malloc( MAX_LETRAS );
    // printf("aloquei dados.\n");
    strcpy(hashArray[hashIndex]->key, key);
    hashArray[hashIndex]->count = 1;

    return;
}

/*
 Initialize an hash array by setting all the nodes to NULL
 Input: Pointer to hashArray array
 Output: None
*/
void initializeHashArray (DataItem** hashArray) {
     int i = 0;
     for (i = 0; i < SIZE; i++) {
        hashArray[i] = NULL;
        // printf("%d: %d\n", i, hashArray[i]);
     }
}

void Inicializa(Seq * vetor, int tam){
    for (int i = 0; i < tam; ++i){
        vetor[i].word = NULL;
        vetor[i].count = 0;
    }
}

int BuscaSequencial(char * word, Seq * vetor, int tam){
    for (int i = 0; i < tam; ++i){
        if(vetor[i].word == NULL) return -1;
        if(!(strcmp(vetor[i].word, word))) return i;
    }
    return -1;
}

int odenacao(const void *a, const void *b){
    char * valor1 = ((Seq *)a)->word;
    char * valor2 = ((Seq *)b)->word;
    return (strcmp(valor1, valor2)); 
}

// Sorts an array of Seqs where length of every 
// string should be smaller than MAX_LEN 
void selectionSort(Seq * arr, int n){ 
    int i, j; 
   
    // One by one move boundary of unsorted subarray 
    char minStr[MAX_LEN]; 
    for (i = 0; i < n-1; i++) 
    { 
        // Find the minimum element in unsorted array 
        int min_idx = i; 
        strcpy(minStr, arr[i].word); 
        for (j = i+1; j < n; j++) 
        { 
            // If min is greater than arr[j].word 
            if (strcmp(minStr, arr[j].word) > 0) 
            { 
                // Make arr[j].word as minStr and update min_idx 
                strcpy(minStr, arr[j].word); 
                min_idx = j; 
            } 
        } 
   
        // Swap the found minimum element with the first element 
        if (min_idx != i) 
        { 
            Seq * temp = (Seq*)malloc(sizeof(Seq)); 
            temp->word = arr[i].word; //swap item[pos] and item[i]
            temp->count = arr[i].count; 
            arr[i].word = arr[min_idx].word; 
            arr[i].count = arr[min_idx].count;
            arr[min_idx].word = temp->word;
            arr[min_idx].count = temp->count;
        } 
    } 
}

void selectionSortString(char *arr[MAX_LEN], int n) { 
    int i, j; 
   
    // One by one move boundary of unsorted subarray 
    char minStr[MAX_LEN]; 
    for (i = 0; i < n-1; i++) 
    { 
        // Find the minimum element in unsorted array 
        int min_idx = i; 
        strcpy(minStr, arr[i]); 
        for (j = i+1; j < n; j++) 
        { 
            // If min is greater than arr[j] 
            if (strcmp(minStr, arr[j]) > 0) 
            { 
                // Make arr[j] as minStr and update min_idx 
                strcpy(minStr, arr[j]); 
                min_idx = j; 
            } 
        } 
   
        // Swap the found minimum element with the first element 
        if (min_idx != i) 
        { 
            char temp[MAX_LEN]; 
            strcpy(temp, arr[i]); //swap item[pos] and item[i] 
            strcpy(arr[i], arr[min_idx]); 
            strcpy(arr[min_idx], temp); 
        } 
    } 
} 