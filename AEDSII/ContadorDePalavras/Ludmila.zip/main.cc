#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "hashTable.h"
#include <ctype.h>

#define MAX_PALAVRAS 10000000

void remove_punct_and_make_lower_case(char *p)
{
  char *src = p, *dst = p;

  while (*src)
  {
    if (ispunct((unsigned char)*src))
    {
      /* Skip this character */
      src++;
    }
    else if (isupper((unsigned char)*src))
    {
      /* Make it lowercase */
      *dst++ = tolower((unsigned char) * src);
      src++;
    }
    else if (src == dst)
    {
      /* Increment both pointers without copying */
      src++;
      dst++;
    }
    else
    {
      /* Copy character */
      *dst++ = *src++;
    }
  }

  *dst = 0;
}

int main( int argc, char **argv ) {
  int contagem_palavras = 0, tamanho_linha_atual = 50 * MAX_LETRAS;
  char* palavra_lida;
  char * linha_atual = (char*) malloc (tamanho_linha_atual);
  char ** palavras = (char**) malloc (sizeof(char *) * MAX_PALAVRAS );
  FILE * arquivoTexto;

  // Checando se pode executar o programa
  if (argc != 5) {
    printf("ERRO: Sao necessarios exatamente 4 parametros para este programa!\n");
    return 0;
  } else if ((atoi(argv[2]) != 0) && (atoi(argv[2]) != 1) && (atoi(argv[3]) != 0) && (atoi(argv[3]) != 1)) {
    printf("ERRO: Favor usar 0 ou 1 para os parametros 2 e 3!\n");
    return 0;
  }


  // Lendo o arquivoTexto texto
  arquivoTexto = fopen(argv[1], "r");
  if (!arquivoTexto) {
    printf("ERRO! arquivo texto nao encontrado.\n");
    return 1;
  }

  printf("Lendo arquivo pra memoria...\n");


  for (int i = 0; i < MAX_PALAVRAS; i++) palavras[i] = (char*) malloc (MAX_LETRAS * sizeof(char)); // alocando a memoria de cada palavra do INPUT (tamanho maximo de 100.000 palavras)

  while (fgets(linha_atual, tamanho_linha_atual, arquivoTexto)) {
    remove_punct_and_make_lower_case(linha_atual);
    palavra_lida = strtok(linha_atual, " \n\0");
    for (; palavra_lida; contagem_palavras++) {
      // printf("%d ", contagem_palavras);
      strcpy(palavras[contagem_palavras], palavra_lida);
      palavra_lida = strtok(NULL, " \n\0");
    }
  }

  printf("Processando dados da memoria...\n");

  if (atoi(argv[2]) == 1) {
    DataItem* hashArray[SIZE];
    initializeHashArray(hashArray);
    for ( int i = 0; i < contagem_palavras; i++) putValueForKey(hashArray, palavras[i], i);

    if (atoi(argv[3]) == 0) {
      printf("Agora vou ordenar por selection sort\n");

      selectionSortString(palavras, contagem_palavras);

    } else {
      printf("Agora vou ordenar por quicksort\n");

      qsort(palavras, contagem_palavras, sizeof(char *), odenacao);

    }

    char ultima_palavra[MAX_LETRAS] = " ";

    FILE * out = fopen(argv[4], "w");

    for(int i = 0; i<contagem_palavras; i++) {
      DataItem *ultimo_item = getValueByKey(hashArray, palavras[i]);
      if(strcmp(ultima_palavra, ultimo_item->key)) {
        // printf("%s %d\n", palavras[i], ultimo_item->count);
        fprintf(out,"%s %d\n", palavras[i], ultimo_item->count);
      } 
      strcpy(ultima_palavra,ultimo_item->key);
    }

  } else {
    //####################### MODO SEQUENCIAL #######################
    printf("Sequencial\n");
    Seq vetor[contagem_palavras];
    int tam;
    Inicializa(vetor, contagem_palavras);
    for (int i = 0; i < contagem_palavras; ++i) {
      int pos;
      pos = BuscaSequencial(palavras[i], vetor, contagem_palavras);
      if (pos == -1) {
        int j = 0;
        while (vetor[j].word != NULL) j++;
        vetor[j].word = palavras[i];
        vetor[j].count++;
      } else {
        vetor[pos].word = palavras[i];
        vetor[pos].count++;
      }
    }
    for (int i = 0; i < contagem_palavras; ++i) {
      if (vetor[i].word == NULL) {
        tam = i;
        break;
      }
    }
    if (atoi(argv[3]) == 0) {
      //####################### SELECTION SORT #######################
      printf("Agora vou ordenar por selection sort\n");
      selectionSort(vetor, tam);
    } else {
      //####################### QUICK SORT #######################
      printf("Agora vou ordenar por quicksort\n");
      qsort(vetor, tam, sizeof(Seq), odenacao);
    }

    //####################### ESCREVE NO ARQUIVO #######################
    FILE * out = fopen(argv[4], "w");
    for (int i = 0; i < tam; ++i) {
      fprintf(out, "%s %d\n", vetor[i].word, vetor[i].count);
      // printf("%s(%d)\n", vetor[i].word, vetor[i].count);
    }
  }





  /*
  printf("Fetching value...\n\n");

  DataItem* item = getValueByKey(hashArray, 100);

  if (item != NULL) {
     printf("Element found: %s\n", item->data);
  }
  else {
     printf("Element not found\n");
  }
  */

  return 0;
}