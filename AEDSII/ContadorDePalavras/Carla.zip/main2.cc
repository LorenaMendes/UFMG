#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <limits.h>
#include <string.h>	
#include <time.h>


//////////////////////////////
// STRUCTS PESQUISA SEQUENCIAL
//////////////////////////////

struct ocorrencia_t {
	char *palavra;
	int count;
	struct ocorrencia_t *next;
};

typedef struct ocorrencia_t ocorrencia;

///////////////////////////////////////
//  STRUCTS PESQUISA HASHTABLE
///////////////////////////////////////

struct elemento_hash {
	char *key;
	int value;
	int count;
	struct elemento_hash *next;
};

typedef struct elemento_hash entry_t;

///////////////////////////////////////
// Estrutura que suporta a tabela hash, ou Hashtable
// (que, na verdade, nada mais eh do que uma lista de ENTRIES)
///////////////////////////////////////
struct hashtable_s {
	int size;
	struct elemento_hash **table;	
};

typedef struct hashtable_s hashtable_t;

void removePontuacaoTransformaMinuscula(char *palavra)
{
    char *origem = palavra, *destino = palavra;

    while (*origem) {
       if (ispunct((unsigned char)*origem)) origem++;
       else if (isupper((unsigned char)*origem)) {
          *destino++ = tolower((unsigned char)*origem);
          origem++;
       }
       else if (origem == destino) {
          destino++;
          origem++;
       }
       else *destino++ = *origem++;
    }

    *destino = 0;
}

///////////////////////////////////////
// Funcao que cria nova hashtable
///////////////////////////////////////
hashtable_t *ht_create( int size ) {

	hashtable_t *hashtable = NULL;
	int i;

	if( size < 1 ) return NULL;
	if( ( hashtable = (hashtable_t*) malloc( sizeof( hashtable_t ) ) ) == NULL ) {
		return NULL;
	}
	if( ( hashtable->table = (entry_t**) malloc( sizeof( entry_t * ) * size ) ) == NULL ) {
		return NULL;
	}
	for( i = 0; i < size; i++ ) {
		hashtable->table[i] = NULL;
	}

	hashtable->size = size;

	return hashtable;	
}

///////////////////////////////////////
// Funcao de hash, que transforma uma string em uma chave numerica
///////////////////////////////////////
int ht_hash( hashtable_t *hashtable, char *key ) {

	unsigned long int hashval;
	int i = 0;

	while( hashval < ULONG_MAX && i < (signed) strlen( key ) ) {
		hashval = hashval << 10;
		hashval += key[ i ];
		i++;
	}

	return hashval % hashtable->size;
}

///////////////////////////////////////
// Insere um par chave-valor na Hashtable
///////////////////////////////////////
void ht_set( hashtable_t *hashtable, char *key, int value ) {
	int bin = ht_hash( hashtable, key );
	entry_t *next = hashtable->table[bin];
	entry_t *last = NULL;

	while( next != NULL && next->key != NULL && strcmp( key, next->key ) > 0 ) {
		last = next;
		next = next->next;
	}

	if( next != NULL && next->key != NULL && strcmp( key, next->key ) == 0 ) {
		next->count++;
	} else {

		entry_t *newpair = (entry_t*) malloc( sizeof( entry_t ) );

		newpair->key = strdup( key );
		newpair->value = value;
		newpair->count = 1;
		newpair->next = NULL;


		if( next == hashtable->table[ bin ] ) {
			newpair->next = next;
			hashtable->table[ bin ] = newpair;
		} else if ( next == NULL ) {
			last->next = newpair;
		} else  {
			newpair->next = next;
			last->next = newpair;
		}
	}
}

///////////////////////////////////////
// Encontra um par chave-valor dentro da hashtable
///////////////////////////////////////
int ht_get( hashtable_t *hashtable, char *key ) {

	entry_t *pair = hashtable->table[ ht_hash( hashtable, key ) ];
	while( pair != NULL && pair->key != NULL && strcmp( key, pair->key ) > 0 ) {
		pair = pair->next;
	}

	if( pair == NULL || pair->key == NULL ) return 0;
	else if(strcmp( pair->key, key)) return 0;
		 else return pair->count;
}


///////////////////////////////////////
// Funcao de ordenacao Bubble Sort -- O(n^2)
///////////////////////////////////////
void bubblesort(char *arr[100], int n) 
{ 
    char temp[100]; 

    for (int j=0; j<n-1; j++) 
    { 
        for (int i=j+1; i<n; i++) 
        { 
            if (strcmp(arr[j], arr[i]) > 0) 
            { 
                strcpy(temp, arr[j]); 
                strcpy(arr[j], arr[i]); 
                strcpy(arr[i], temp); 
            } 
        } 
    } 
} 

///////////////////////////////////////
// Funcao auxilizar para a Quick Sort
///////////////////////////////////////
int sortstring(const void * a, const void * b){
    char **A = (char **)a;
    char **B = (char **)b;
    return strcmp(*A, *B);
}

///////////////////////////////////////
// Construtor da estrutura de pesquisa sequencial
///////////////////////////////////////
ocorrencia *newPalavra(char* palavra) {
	ocorrencia *aux = (ocorrencia*) malloc(sizeof(ocorrencia));

	aux->next = NULL;
	aux->palavra = (char*) malloc(500);
	strcpy(aux->palavra,palavra);
	aux->count = 1;

	return aux;
}

///////////////////////////////////////
// Buscador da pesquisa sequencial
///////////////////////////////////////
ocorrencia* searchPalavra(char* palavra, ocorrencia *listaOcorrencias) {
	for(ocorrencia *aux = listaOcorrencias;aux != NULL;aux = aux->next) {
		if(strcmp(palavra,aux->palavra) == 0) return aux;
	}
	return NULL;
}

int main( int argc, char **argv ) {
	///////////////////////////////////////////
	// DECLARACOES DE VARIAVEIS              //
	///////////////////////////////////////////
	hashtable_t *hashtable;
	ocorrencia *listaOcorrencias = NULL;
	int nPalavras = 10000000; //= 25000000
	int tamanhoPalavra = 60;
	int op, tam=0;
	char ordenacao[30],pesquisa[30];
	char * line_in = (char*) malloc (tamanhoPalavra * 20); // variavel que armazena uma linha do arquivo
	char ** palavras = (char**) malloc (nPalavras * sizeof(char *));
	clock_t end, begin = clock();
	FILE * arq;

	///////////////////////////////////////////
	// ASSERCAO DOS INPUTS DO PROGRAMA       //
	///////////////////////////////////////////
	if(argc < 5) {
		return 1;
	} else if((atoi(argv[2]) == 0) && (atoi(argv[3]) == 0)) {
		strcpy(ordenacao,"BubbleSort");
		strcpy(pesquisa,"Pesquisa Sequencial");
		op = 0;
	} else if((atoi(argv[2]) == 0) && (atoi(argv[3]) == 1)) {
		strcpy(ordenacao,"Quicksort");
		strcpy(pesquisa,"Pesquisa Sequencial");
		op = 1;
	} else if((atoi(argv[2]) == 1) && (atoi(argv[3]) == 0)) {
		strcpy(ordenacao,"BubbleSort");
		strcpy(pesquisa,"Tabela Hash");
		op = 2;
	} else if((atoi(argv[2]) == 1) && (atoi(argv[3]) == 1)) {
		strcpy(ordenacao,"Quicksort");
		strcpy(pesquisa,"Tabela Hash");
		op = 3;
	} else {
		return 1;
	}

	end = clock();

	///////////////////////////////////////////
	// TRATAMENTO DO ARQUIVO DE INPUT        //
	///////////////////////////////////////////
	end = clock();
	arq = fopen(argv[1], "r");
	if(arq == NULL) {
		printf("ERRO! Arquivo nao encontrado.\n");
		return 1;
	}
	end = clock();
	for(int i=0; i<nPalavras; i++) palavras[i] = (char*) malloc (tamanhoPalavra * sizeof(char)); // alocando a memoria de cada palavra do INPUT (tamanho maximo de 100.000 palavras)
	while(fgets(line_in, tamanhoPalavra * 20, arq)){
			removePontuacaoTransformaMinuscula(line_in);
			char* token = strtok(line_in, " \n\0");
			while (token) {
			    // populo a linha lida do arquivo para o meu vetor de palavras a serem tratadas
			    strcpy(palavras[tam], token);

			    tam++;

			    token = strtok(NULL, " \n\0");
			}			
	}
	fclose(arq);

	///////////////////////////////////////////
	// PROCESSAMENTO DOS DADOS               //
	///////////////////////////////////////////
	end = clock();
	if(op>1) {
		hashtable = ht_create( 128 * 1024 ); // cerca de 130 K posicoes
		for(int i=0; i<tam; i++) {
		    ht_set( hashtable, palavras[i], i );
		}
	} 
	else {
		for(int i=0; i<tam; i++) {
			if(listaOcorrencias == NULL) {
				listaOcorrencias = newPalavra(palavras[i]);
			}
			else {
				ocorrencia *tmp;
				if(strcmp(palavras[i],listaOcorrencias->palavra) == 0) {
						listaOcorrencias->count++;
				}

				for(tmp = listaOcorrencias;tmp->next != NULL;tmp = tmp->next) {
					if(strcmp(palavras[i],tmp->next->palavra) == 0) tmp->next->count++;
				}

				tmp->next = newPalavra(palavras[i]);				
			}
		}
	}

	///////////////////////////////////////////
	// ORDENACAO E PREPARACAO PARA IMPRESSAO //
	///////////////////////////////////////////
	end = clock();
	if(atoi(argv[3]) == 1) {
		qsort (palavras, tam, sizeof(char *), sortstring);
	} 
	else { 
		bubblesort (palavras, tam); 
	}


	///////////////////////////////////////////
	// IMPRESSAO                             //
	///////////////////////////////////////////
	end = clock();
	FILE * output = fopen(argv[4], "w");
	char aux[100];
	strcpy(aux,"\0");
	if(op > 1) {
		ht_get( hashtable, palavras[0]);
		for(int i=0;i<tam;i++) {
			if(strcmp(palavras[i],aux) != 0) {
				fprintf(output,"%s %d\n",palavras[i],ht_get( hashtable, palavras[i]));
			}
			strcpy(aux,palavras[i]);
		}
	} else {
		for(int i=0;i<tam;i++) {
			if(strcmp(palavras[i],aux) != 0) {
				fprintf(output,"%s %d\n",palavras[i],(searchPalavra(palavras[i],listaOcorrencias))->count);
			}
			strcpy(aux,palavras[i]);
		}
	}

	fclose(output);

	end = clock();

	printf("Tempo de execução: %g segundos\n",(double)(end - begin) / CLOCKS_PER_SEC);

	return 0;
}
