#include <stdio.h>
#include <stdlib.h>
#include "TMatriz.h"

TMatriz CriaMatrizVazia(int m, int n){	//Função para criar matrizes de tamanho mxn com todos os valores iguais a zero
	TMatriz mat;	//declara um objeto do tipo TMatriz
	int i;
	mat.matriz = (float**) calloc (m,sizeof(float*));	//aloca dinamicamente um espaço para as colunas
	for(i=0;i<m;i++){
		mat.matriz[i] = (float*) calloc (n,sizeof(float)); //aloca dinamicamente um espaço para as linhas
	}
	mat.linhas = m;	//atribui os parâmetros de linhas e colunas aos "atributos" da "classe"
	mat.colunas = n;
	return mat;	//retorna o objeto criado
	
}

TMatriz Identidade(int n){	//Função para criar matrizes identidade de tamanho nxn
	TMatriz id = CriaMatrizVazia(n,n);	//cria uma matriz vazia de tamanho nxn
	int i,j;
	printf("Matriz identidade criada com sucesso!\n");
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			if(i==j) id.matriz[i][j] = 1;	//atribui valor 1 a todos os elementos da diagonal
		}
	}
	return id;	//retorna o objeto criado
}

void ImprimeMatriz(TMatriz A){	//Função para imprimir uma matriz
	int i,j;
	for(i=0;i<A.linhas;i++){
		for(j=0;j<A.colunas;j++){
			printf("%.2f ",A.matriz[i][j]);	//imprime o que estiver na posição indicada da matriz
		}
	printf("\n");	//separa cada linha da matriz ao mostrar na tela
	}
	printf("\n\n");
}

float GetElem(TMatriz A, int m, int n){	//Função para obter determinado elemento de uma matriz
	if(m < 0 || m > A.linhas || n < 0 || n > A.colunas)
		return -1;	//retorna -1 se os parâmetros forem inválidos
	return A.matriz[m][n];	//retorna o elemento da matriz na posição indicada
}

int SetElem(TMatriz A, int m, int n, float v){	//Função para alterar o valor de determinado elemento de uma matriz
	if(GetElem(A,m,n) == -1)	//se os parâmetros forem inválidos, retorna -1
		return -1;
	A.matriz[m][n] = v;	//seta o elemento na posição indicada com o valor passado por parâmetro
	return 0;
}

void GetTamanho(TMatriz A, int *m, int *n){	//Função para obter as dimensões de uma matriz, guardando-as em varaiáveis
	*m = A.linhas;	//atribui o número de linhas da matriz A à variável m
	*n = A.colunas;	//atribui o número de colunas da matriz A à variável n
}

TMatriz Soma(TMatriz A, TMatriz B){	//Função para somar duas matrizes
	if(!(A.linhas == B.linhas && A.colunas == B.colunas)){	//confere se as matrizes têm dimensõe iguais
		printf("Impossível somar! As matrizes devem ser iguais!\n");
		return CriaMatrizVazia(0,0);	//se não tiverem, retorna uma matriz de dimensão 0x0
	}
	TMatriz C = CriaMatrizVazia(A.linhas,A.colunas);	//cria uma matriz vazia com a dimensão de A e B
	int i,j;
	printf("Soma efetuada com sucesso!\n");
	for(i=0;i<A.linhas;i++){
		for(j=0;j<A.colunas;j++){
			C.matriz[i][j] = A.matriz[i][j] + B.matriz[i][j];	//atribui à nova matriz os valores da soma dos elementos de A e B
		}
	}
	return C; //retorna a matriz C
}

TMatriz Multiplica(TMatriz A, TMatriz B){	//Função para multiplicar duas matrizes
	if(A.colunas != B.linhas){	//confere se as dimensões das matrizes são compatíveis pra multiplicar
		printf("Impossível multiplicar!\n");
		return CriaMatrizVazia(0,0);	//se não tiverem, retorna uma matriz de dimensão 0x0
	}
	TMatriz C = CriaMatrizVazia(A.linhas,B.colunas);	//cria uma matriz vazia de dimensão (A.linhas)x(B.colunas)
	int i,j,k;
	printf("Multiplicação efetuada com sucesso!\n");
	for(i=0;i<A.linhas;i++){
		for(j=0;j<B.colunas;j++){
			for(k=0;k<A.linhas;k++){
				C.matriz[i][j] += A.matriz[i][k] * B.matriz[k][j];	//atribui à nova matriz o produto de A e B
			}
		}
	}
	return C;	//retorna a matriz C
}

TMatriz Transpoe(TMatriz A){	//Função para transpor uma matriz
	TMatriz trans = CriaMatrizVazia(A.colunas,A.linhas);	//cria um objeto do tipo TMatriz
	int i,j;
	printf("Transposição feita com sucesso!\n");
	for(i=0;i<A.linhas;i++){
		for(j=0;j<A.colunas;j++){
			trans.matriz[j][i] = A.matriz[i][j];	//atribui ao objeto criado a transposição da matriz passada por parâmetro
		}
	}
	return trans;	//retorna a matriz transposta
}
