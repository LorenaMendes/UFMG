#include <stdio.h>
#include <stdlib.h>
#include "TMatriz.h"

int main(){
	//Cria uma matriz 2x2 e atribui valores a ela.
	TMatriz a = CriaMatrizVazia(2,2);
	SetElem(a,0,0,2);
	SetElem(a,0,1,3);
	SetElem(a,1,0,5);
	SetElem(a,1,1,2);
	ImprimeMatriz(a);
	
	//Cria uma matriz 2x2 e atribui valores a ela.
	TMatriz b = CriaMatrizVazia(2,2);
	SetElem(b,0,0,4);
	SetElem(b,0,1,1);
	SetElem(b,1,0,6);
	SetElem(b,1,1,4);
	ImprimeMatriz(b);

	//Cria uma matriz 2x3 e atribui valores a ela.
	TMatriz c = CriaMatrizVazia(2,3);
	SetElem(c,0,0,4);
	SetElem(c,0,1,1);
	SetElem(c,0,2,6);
	SetElem(c,1,0,4);
	SetElem(c,1,1,3);
	SetElem(c,1,2,7);
	ImprimeMatriz(c);
	
	//Cria uma matriz 3x4 e atribui valores a ela.
	TMatriz d = CriaMatrizVazia(3,4);
	SetElem(d,0,0,4);
	SetElem(d,0,1,1);
	SetElem(d,0,2,5);
	SetElem(d,0,3,0);
	SetElem(d,1,0,2);
	SetElem(d,1,1,4);
	SetElem(d,1,2,8);
	SetElem(d,1,3,3);
	SetElem(d,2,0,2);
	SetElem(d,2,1,0);
	SetElem(d,2,2,3);
	SetElem(d,2,3,4);
	ImprimeMatriz(d);
	
	//Cria uma matriz identidade de dimensão 5.
	TMatriz i5 = Identidade(5);
	ImprimeMatriz(i5);
	 
	//Cria uma matriz que é a transposta de a.
	TMatriz ta = Transpoe(a);
	ImprimeMatriz(ta);

	//Cria uma matriz que é a transposta de d.
	TMatriz td = Transpoe(d);
	ImprimeMatriz(td);
	
	//Mostra as dimensões da matriz c.
	int m, n;
	GetTamanho(c,&m,&n);
	printf("%dx%d\n",m,n);
	
	//Pega o elemento na posição 2,1 da matriz d.
	float ed = GetElem(d,2,2);
	printf("Elemento na posição 2x1 da matriz d: %.2f\n\n",ed);
	
	//Tenta somar a matriz a com a matriz c (elas têm dimensões diferentes)
	TMatriz AmaisC = Soma(a,c);
	ImprimeMatriz(AmaisC);
	
	//Soma as matrizes a e b.
	TMatriz AmaisB = Soma(a,b);
	ImprimeMatriz(AmaisB);
	
	//Tenta multiplicar as matrizes b e d (dimensões não compatíveis)
	TMatriz BxD = Multiplica(b,d);
	ImprimeMatriz(BxD);
	
	//Multiplica as matrizes c e d (dimensões compatíveis)
	TMatriz CxD = Multiplica(c,d);
	ImprimeMatriz(CxD);

	return 0;
}
