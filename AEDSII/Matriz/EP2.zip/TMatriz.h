#ifndef LOLAMATRIZ
#define LOLAMATRIZ
#include <stdio.h>
#include <stdlib.h>

typedef struct TMatriz{
	int linhas;
	int colunas;
	float **matriz;
} TMatriz;

TMatriz CriaMatrizVazia(int m, int n);

TMatriz Identidade(int n);

void ImprimeMatriz(TMatriz A);

float GetElem(TMatriz A, int m, int n);

int SetElem(TMatriz A, int m, int n, float v);

void GetTamanho(TMatriz A, int *m, int *n);

TMatriz Soma(TMatriz A, TMatriz B);

TMatriz Multiplica(TMatriz A, TMatriz B);

TMatriz Transpoe(TMatriz A);

#endif
