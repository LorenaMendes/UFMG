/*
UNIVERSIDADE FEDERAL DE MINAS GERAIS
DEPARTAMENTO DE CIÊNCIA DA COMPUTAÇÃO
ALGORITMOS E ESTRUTURAS DE DADOS II
======================================
TP2: ÁRVORE QUADRUPLA
PROFESSORES: 	Fernando Magno Q. Pereira
				Luiz Chaimowicz
				Raquel Minardi
MONITOR: 		Pedro Ramos (Sala 2301)
ALUNA:			Lorena Mendes Peixoto
======================================

Módulo: arvorequad.h

Este cabeçalho contém a declaração dos métodos do módulo arvorequad.c, bem
como a definição das estruturas a serem utilizadas nesse trablho. Muita atenção
à estrutura: qualquer modificação na mesma pode interferir no resultado esperado
na rotina "imprimeArvoreEmArquivoDot(ArvoreQuad* )".

Neste trabalho vocês irão implementar uma árvore quádrupla. Não se desesperem!
Uma árvore quádrupla é aquela em que cada nó possui 4 filhos. Dessa vez,
queremos dividir partículas num espaço 2D em quadrantes. Quando X ou mais
partículas ocupam o mesmo quadrante no espaço 2D, o mesmo é dividido em outros
4 subquadrantes filhos, e a partícula é então movida para o subquadrante
filho em que ela se situa.

Cada quadrante é classificado de acordo com o centro do quadrante pai. Há,
então, 4 quadrantes para um centro do quadrante pai:
NE -> Quadrante Nordeste ao centro
NW -> Quadrante Noroeste ao centro
SE -> Quadrante Sudeste ao centro
SW -> Quadrante Sudoeste ao centro

Estes quadrantes (e seus filhos, e os filhos de seus filhos...) podem ser
representados por uma árvore quádrupla. Quando uma partícula nova é adicionada
à árvore, você deve checar se ela vai entrar em um quadrante que já contém
o número máximo de partículas permitido. Se isso ocorrer, você deve partir
este quadrante em mais 4 subquadrantes e mover as partículas para baixo,
atualizando o peso e o centro de cada novo subquadrante.

*/
#ifndef __ARVORE_QUAD_H__
#define __ARVORE_QUAD_H__
#define LARGURA_MAXIMA 60

typedef struct Quadrante Quadrante;
typedef struct Ponto Ponto;
typedef struct Estrela Estrela;

//Estrutura que define um ponto no espaço 2D
struct Ponto
{
	int x;
	int y;
};

//Estrutura da partícula. Possui um ponto p e um peso inteiro.
struct Estrela
{
	Ponto p;
	int peso;
};

struct Quadrante
{
	//quadrantes filhos, se existirem
	Quadrante* NE;
	Quadrante* NW;
	Quadrante* SE;
	Quadrante* SW;
	//estrela do quadrante, se existir
	Estrela* star;
	//centro do quadrante
	Ponto centro;
	//coordenadas do vértice no noroeste
	Ponto NW_;
	//coordenadas do vértice no sudeste
	Ponto SE_;
	//peso total do quadrante
	int peso;
};

Quadrante * NovoQuadrante(int SEx, int SEy, int NWx, int NWy);
void Insere(Quadrante * quad, Estrela * star);
void Imprime(Quadrante * quad, int espacos);

#endif