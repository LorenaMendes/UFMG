/*
UNIVERSIDADE FEDERAL DE MINAS GERAIS
DEPARTAMENTO DE CIÊNCIA DA COMPUTAÇÃO
ALGORITMOS E ESTRUTURAS DE DADOS II
======================================
TP2: ÁRVORE QUADRUPLA
PROFESSORES: 	Fernando Magno Q. Pereira
				Luiz Chaimowicz
				Raquel Minardi
MONITOR: 		Pedro Ramos (Sala 2301)
ALUNA:			Lorena Mendes Peixoto
======================================

Módulo: main.c
*/

#include "arvorequad.h"
#include "dot.h"

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const *argv[]){
	

	printf("\nDigite L (largura maxima) e N (numero de estrelas): ");
	int tamanho_mapa, numero_estrelas;
	scanf("%d%d", &tamanho_mapa, &numero_estrelas);
	
	Estrela * star;
	star = malloc(sizeof(Estrela));

	Quadrante * quad;
	quad = malloc(sizeof(Quadrante));
	quad = NovoQuadrante(tamanho_mapa, 0, 0, tamanho_mapa);

	int i;
	for (i = 0; i < numero_estrelas; i++) {
		printf("\nEntre com a proxima estrela (x, y, peso): ");
		scanf("%d%d%d", &star->p.x, &star->p.y, &star->peso);
		// printf("%d %d %d", star->p.x, star->p.y, star->peso);
		Insere(quad, star);
		printf("Impressao: \n");
		Imprime(quad,0);
		printf("-------------------------------\n");
	}

	imprimeArvoreQuadruplaEmArquivoDot(quad, "saida.dot");

	return 0;
}