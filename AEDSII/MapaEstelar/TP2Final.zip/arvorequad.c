/*
UNIVERSIDADE FEDERAL DE MINAS GERAIS
DEPARTAMENTO DE CIÊNCIA DA COMPUTAÇÃO
ALGORITMOS E ESTRUTURAS DE DADOS II
======================================
TP2: ÁRVORE QUADRUPLA
PROFESSORES: 	Fernando Magno Q. Pereira
				Luiz Chaimowicz
				Raquel Minardi
MONITOR: 		Pedro Ramos (Sala 2301)
ALUNA:			Lorena Mendes Peixoto
======================================

Módulo: arvorequad.c
*/

#include "arvorequad.h"
#include <stdlib.h>
#include <stdio.h>

//função construtora de um quadrante
//constroi um quadrante a partir das coordenadas do Sudeste e das do Noroeste
Quadrante * NovoQuadrante(int SEx, int SEy, int NWx, int NWy) {
	Quadrante * novo;
	novo = malloc(sizeof(Quadrante));
	novo->star = NULL;	//inicializa o quadrante sem estrelas
	novo->peso = 0;	//inicializa o quadrante com peso igual a 0
	novo->NE = NULL; //inicializa um quadrante sem filhos
	novo->NW = NULL;
	novo->SE = NULL;
	novo->SW = NULL;
	novo->centro.x = NWx + ((SEx - NWx) / 2);	//inicializa as coordenadas do centro
	novo->centro.y = SEy + ((NWy - SEy) / 2);
	novo->SE_.x = SEx;	//armazena as coordenadas passadas por parâmetro
	novo->SE_.y = SEy;
	novo->NW_.x = NWx;
	novo->NW_.y = NWy;
	// printf("Criei novo quadrante: (%d,%d)\n",novo->centro.x, novo->centro.y);
	return novo;	//retorna um novo quadrante
}

void Insere(Quadrante * quad, Estrela * starNova) {
	printf("Vou inserir a estrela de peso %d no quadrante de centro (%d,%d)\n", starNova->peso, quad->centro.x, quad->centro.x);
	
	if (!quad->NE) {
		printf("Não há filhos, ");
		if (!quad->star) {
			printf("não há estrelas\n");
			// quad->star = starNova;

			quad->star = malloc(sizeof(Estrela));

			quad->star->p.x = starNova->p.x;
			quad->star->p.y = starNova->p.y;
			quad->star->peso = starNova->peso;

			quad->peso = starNova->peso;
			printf("Inserido: (%d,%d) %d\n", quad->star->p.x, quad->star->p.y, quad->star->peso);
		} else {
			printf("mas há estrela: (%d,%d) %d\n", quad->star->p.x, quad->star->p.y, quad->star->peso);
			if (((quad->SE_.x - quad->NW_.x)) <= 1 || ((quad->NW_.y - quad->SE_.y)) <= 1) {
				printf("Nao posso quebrar mais, aresta ja vale 1. Somando as gravidades... \n");
				quad->peso += starNova->peso;
				return;
			} else {
				printf("Obs.: tamanho da aresta: %d peso: %d\n", (quad->SE_.x - quad->NW_.x), quad->peso);
			}
			printf("Precisarei subdividir esses quadrante\n");
			quad->NE = NovoQuadrante(quad->SE_.x, ((quad->NW_.y + quad->SE_.y) / 2), ((quad->SE_.x + quad->NW_.x) / 2), quad->NW_.y);
			printf("Centro do filho NE: (%d,%d)\n", quad->NE->centro.x, quad->NE->centro.y);
			quad->NW = NovoQuadrante(((quad->SE_.x + quad->NW_.x) / 2), ((quad->NW_.y + quad->SE_.y) / 2), quad->NW_.x, quad->NW_.y);
			printf("Centro do filho NW: (%d,%d)\n", quad->NW->centro.x, quad->NW->centro.y);
			quad->SE = NovoQuadrante(quad->SE_.x, quad->SE_.y, ((quad->SE_.x + quad->NW_.x) / 2), ((quad->NW_.y + quad->SE_.y) / 2));
			printf("Centro do filho SE: (%d,%d)\n", quad->SE->centro.x, quad->SE->centro.y);
			quad->SW = NovoQuadrante(((quad->SE_.x + quad->NW_.x) / 2), quad->SE_.y, quad->NW_.x, ((quad->NW_.y + quad->SE_.y) / 2));
			printf("Centro do filho SW: (%d,%d)\n", quad->SW->centro.x, quad->SW->centro.y);
			printf("Agora que quebrei em quadrantes, vou retirar a estrela que estava no pai e procurar o lugar dela.\n");

			Estrela * temp;
			temp = malloc(sizeof(Estrela));
			temp->p.x = quad->star->p.x;
			temp->p.y = quad->star->p.y;
			temp->peso = quad->star->peso;

			// printf("star: (%d,%d) %d\n",temp->p.x, temp->p.y, temp->peso);
			free(quad->star);
			quad->star = NULL;

			// quad->peso += starNova->peso;

			// realoca estrela atual para um dos 4 quadrantes filhos
			printf("Encontrei o lugar dela. Está em ");
			if (temp->p.x < ((quad->SE_.x + quad->NW_.x) / 2)) {
				// printf("Estou no Oeste, meu x é menor que %d\n", (quad->SE_.x + quad->NW_.x)/2);
				if (temp->p.y < ((quad->NW_.y + quad->SE_.y) / 2)) {
					quad->SW->peso = temp->peso;
					printf("SW.\n");
					// printf("Meu y é menor que %d\n", (quad->SE_.x + quad->NW_.x)/2);
					printf("Entrei em SW para realocar a estrela que já tinha... ");
					printf("Eu pretendo inserir (%d,%d) %d no SW\n", temp->p.x, temp->p.y, temp->peso);
					Insere(quad->SW, temp);
				} else {
					quad->NW->peso = temp->peso;
					printf("NW.\n");
					// printf("Meu y é menor que %d\n", (quad->SE_.x + quad->NW_.x)/2);
					printf("Entrei em NW para realocar a estrela que já tinha... ");
					printf("Eu pretendo inserir (%d,%d) %d no NW\n", temp->p.x, temp->p.y, temp->peso);
					Insere(quad->NW, temp);
				}
			} else {
				// printf("Estou no Leste, meu x é maior ou igual a %d\n", (quad->SE_.x + quad->NW_.x)/2);
				if (temp->p.y < ((quad->NW_.y + quad->SE_.y) / 2)) {
					quad->SE->peso = temp->peso;
					printf("SE.\n");
					// printf("Meu y é menor que %d\n", (quad->SE_.x + quad->NW_.x)/2);
					printf("Entrei em SE para realocar a estrela que já tinha... ");
					printf("Eu pretendo inserir (%d,%d) %d no SE\n", temp->p.x, temp->p.y, temp->peso);
					Insere(quad->SE, temp);
				} else {
					quad->NE->peso = temp->peso;
					printf("NE.\n");
					// printf("Meu y é menor que %d\n", (quad->SE_.x + quad->NW_.x)/2);
					printf("Entrei em NE para realocar a estrela que já tinha... ");
					printf("Eu pretendo inserir (%d,%d) %d no NE\n", temp->p.x, temp->p.y, temp->peso);
					Insere(quad->NE, temp);
				}
			}

			printf("Ajustei a estrela anterior.\n");

			// insere a nova estrela
			printf("Agora eu pretendo inserir (%d,%d) %d\n", starNova->p.x, starNova->p.y, starNova->peso);
			printf("Inserindo (%d,%d) %d\n", starNova->p.x, starNova->p.y, starNova->peso);
			// return;

			printf("SE_x: %d; SE_y: %d; NW_x: %d; NW_y: %d\n", quad->SE_.x, quad->SE_.y, quad->NW_.x, quad->NW_.y);
			if (starNova->p.x < ((quad->SE_.x + quad->NW_.x) / 2)) {
				if (starNova->p.y < ((quad->NW_.y + quad->SE_.y) / 2)) {
					// quad->SW->peso = starNova->peso;
					printf("Entrei em SW para inserir a nova... ");
					Insere(quad->SW, starNova);
				} else {
					// quad->NW->peso = starNova->peso;
					printf("Entrei em NW para inserir a nova... ");
					Insere(quad->NW, starNova);
				}
			} else {
				if (starNova->p.y < ((quad->NW_.y + quad->SE_.y) / 2)) {
					// quad->SE->peso = starNova->peso;
					printf("Entrei em SE para inserir a nova... ");
					Insere(quad->SE, starNova);
				} else {
					// quad->NE->peso = starNova->peso;
					printf("Entrei em NE para inserir a nova... ");
					Insere(quad->NE, starNova);
				}
			}
			quad->peso += starNova->peso;
			// Insere(quad, starNova);
			printf("Coloquei a nova estrela\n");
		}
	} else {
		printf("Há filhos.\n");
		quad->peso += starNova->peso;
		printf("Somei %d\n", starNova->peso);
		if (starNova->p.x < ((quad->SE_.x + quad->NW_.x) / 2)) {
			if (starNova->p.y < ((quad->NW_.y + quad->SE_.y) / 2)) {
				printf("Entrei em SW.\n");
				Insere(quad->SW, starNova);
				return;
			}
			else {
				printf("Entrei em NW.\n");
				Insere(quad->NW, starNova);
				return;
			}
		} else {
			if (starNova->p.y < ((quad->NW_.y + quad->SE_.y) / 2)) {
				printf("Entrei em SE.\n");
				Insere(quad->SE, starNova);
				return;
			}
			else {
				printf("Entrei em NE.\n");
				Insere(quad->NE, starNova);
				return;
			}
		}
	}
}

void Imprime(Quadrante * quad, int espacos) {
	if (quad->NE) {
		Imprime(quad->NE, espacos + 1);
		Imprime(quad->NW, espacos + 1);
		Imprime(quad->SW, espacos + 1);
		Imprime(quad->SE, espacos + 1);
	}
	for (int i = 0; i < espacos; i++) printf(" ");
	printf("%d %d %d\n", quad->centro.x, quad->centro.y, quad->peso);
}